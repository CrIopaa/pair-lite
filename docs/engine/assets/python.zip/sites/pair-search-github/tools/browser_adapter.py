"""Runtime adapters only. Preserved numerical modules execute inside Pyodide."""
from pathlib import Path
import json,sys,types
import numpy as np
sys.path.insert(0,'/project/setup-search')
import subprocess
from js import pairSubprocess
# Emscripten virtual files are bytes, not an OS mmap; values/order stay exact.
def memory_file(filename,dtype=float,mode='r+',offset=0,shape=None,order='C'):
 if mode not in ['r','c']:raise ValueError('Browser market maps are read-only')
 a=np.frombuffer(Path(filename).read_bytes(),dtype=dtype,offset=offset)
 return a.reshape(shape,order=order)if shape else a
np.memmap=memory_file

def run_bridge(args,**kwargs):
 code=int(pairSubprocess(json.dumps([str(a)for a in args])))
 if code and kwargs.get('check'):raise RuntimeError('Browser numerical subprocess failed')
 return types.SimpleNamespace(returncode=code,stdout='',stderr='')
subprocess.run=run_bridge
import engine

def scan(snapshot,definition,frame,settings):
 return json.dumps(engine.execute(snapshot,definition,frame,settings),separators=(',',':'),allow_nan=False)

def chart(snapshot,L,S,frame,recovery=False,dailyOverview=False):
 v=engine.Search(snapshot,frame)
 if L not in v.by or S not in v.by:raise ValueError('Chart history unavailable')
 a,b=v.by[L]['bars'],v.by[S]['bars'];n=min(len(a),len(b));a,b=a[-n:],b[-n:]
 if [x[0]for x in a]!=[x[0]for x in b]:raise ValueError('Chart history timestamps differ')
 r={'prices':[[x[6],x[4],y[4]]for x,y in zip(a,b)],'points':[[x[6],x[4]/y[4]]for x,y in zip(a,b)],'legs':[[x[6],100*x[4]/a[0][4],100*y[4]/b[0][4]]for x,y in zip(a,b)],'numerator':L,'denominator':S,'frame':frame,'source':'Synchronous completed trade closes, calculated in this browser. No fabricated ratio wicks.'}
 if dailyOverview and frame!='daily':
  d=engine.Search(snapshot,'daily');aa,bb=d.by[L]['bars'],d.by[S]['bars'];nn=min(len(aa),len(bb));aa,bb=aa[-nn:],bb[-nn:]
  if [x[0]for x in aa]!=[x[0]for x in bb]:raise ValueError('Daily histories differ')
  r['dailyOverview']={'points':[[x[6],x[4]/y[4]]for x,y in zip(aa,bb)],'frame':'daily','lastCompletedBar':d.cut-1}
 return json.dumps(r,separators=(',',':'),allow_nan=False)
