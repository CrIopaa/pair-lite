"""Closed-bar feature fingerprints and a bounded, train-only combination search."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,itertools,math
import numpy as np
P=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
EPS=1e-9

def clean(x):
 if isinstance(x,np.ndarray):return [clean(v)for v in x]
 if isinstance(x,(np.floating,float)):return float(x) if np.isfinite(x) else None
 if isinstance(x,np.integer):return int(x)
 if isinstance(x,np.bool_):return bool(x)
 if isinstance(x,dict):return {k:clean(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v)for v in x]
 return x

def write(name,x):
 path=P/name;assert not path.exists(),f'Preserve {name}';path.write_text(json.dumps(clean(x),separators=(',',':'),allow_nan=False)+'\n')

def roll(x,n,kind='mean',past=False):
 out=np.full(len(x),np.nan)
 for i in range(n-1+past,len(x)):
  w=x[i-n+1-past:i+1-past]
  if np.isfinite(w).all():
   if kind=='mean':out[i]=np.mean(w)
   elif kind=='sd':out[i]=np.std(w,ddof=1)
   elif kind=='pop':out[i]=np.std(w)
   elif kind=='min':out[i]=np.min(w)
   elif kind=='max':out[i]=np.max(w)
 return out

def ema(x,n):
 out=np.full(len(x),np.nan);seed=[];value=None
 for i,v in enumerate(x):
  if not np.isfinite(v):seed=[];value=None;continue
  if value is None:
   seed.append(v)
   if len(seed)<n:continue
   value=sum(seed[-n:])/n
  else:value=(2*v+(n-1)*value)/(n+1)
  out[i]=value
 return out

def rsi(x,n=14):
 out=np.full(len(x),np.nan);g=[];l=[];ag=al=None
 for i in range(1,len(x)):
  if not(np.isfinite(x[i])and np.isfinite(x[i-1])):g=[];l=[];ag=al=None;continue
  v=x[i]-x[i-1];up=max(v,0);down=max(-v,0)
  if ag is None:
   g.append(up);l.append(down)
   if len(g)<n:continue
   ag=sum(g)/n;al=sum(l)/n
  else:ag=((n-1)*ag+up)/n;al=((n-1)*al+down)/n
  if ag+al>0:out[i]=100*ag/(ag+al)
 return out

def pivots(x,tolerance=EPS):
 """Return confirmed plateau turns; t is confirmation, t-1 is final plateau bar."""
 out={};last=None;trend=0;plateau=None;low=high=None
 for i,v in enumerate(x):
  if not np.isfinite(v):last=None;trend=0;low=high=None;plateau=None;continue
  if last is None:last=v;plateau=i;continue
  d=v-last
  if abs(d)<=tolerance:last=v;continue
  direction=1 if d>0 else -1
  if trend and direction!=trend:
   side='low' if direction>0 else 'high';previous=low if side=='low' else high
   out[i]={'side':side,'index':i-1,'value':float(last),'previous':previous}
   if side=='low':low=(i-1,float(last))
   else:high=(i-1,float(last))
  trend=direction;last=v;plateau=i
 return out

def features(barsa,barsb):
 a=np.array(barsa,float);b=np.array(barsb,float);assert np.array_equal(a[:,0],b[:,0]);assert np.array_equal(a[:,6],b[:,6]);assert (a[:,4]>0).all()and(b[:,4]>0).all()
 q=a[:,4]/b[:,4];y=np.log(q);ret=np.r_[np.nan,np.diff(y)];R=rsi(q);mn=roll(R,14,'min');mx=roll(R,14,'max')
 with np.errstate(divide='ignore',invalid='ignore'):fast=np.where(mx>mn,100*(R-mn)/(mx-mn),np.nan)
 fast=np.clip(fast,0,100);K=roll(fast,3);D=roll(K,3);s20=roll(q,20);pop20=roll(q,20,'pop');lo=roll(q,20,'min');hi=roll(q,20,'max');lo14=roll(q,14,'min');hi14=roll(q,14,'max')
 with np.errstate(divide='ignore',invalid='ignore'):
  f={'rsi14':R,'k':K,'d':D,'bbz20':(q-s20)/pop20,'bb_percent_b':.5+(q-s20)/(4*pop20),'closepos20':(q-lo)/(hi-lo),'close_stoch14':100*(q-lo14)/(hi14-lo14),'z180':(y-roll(y,180,past=True))/roll(y,180,'sd',True),'vol10_30':roll(ret,10,'sd')/roll(ret,30,'sd')}
  for n in [5,20,50]:f['ma'+str(n)+'dist']=100*(q/roll(q,n)-1)
  s50=roll(q,50);f['ma50slope5_sd']=abs(np.r_[np.full(5,np.nan),np.log(s50[5:]/s50[:-5])])/roll(y,180,'sd',True)
  for n in [1,3,10]:f['roc'+str(n)]=np.r_[np.full(n,np.nan),y[n:]-y[:-n]]*100
 C=np.full(len(q),np.nan)
 for i in range(19,len(q)):
  w=q[i-19:i+1];mad=np.mean(abs(w-np.mean(w)))
  if mad>0:C[i]=(q[i]-np.mean(w))/(.015*mad)
 f['cci20']=C;M=ema(q,12)-ema(q,26);S=ema(M,9);H=M-S;f['macd']=100*M/q;f['macd_signal']=100*S/q;f['macd_hist']=100*H/q;f['macd_hist_delta']=100*np.r_[np.nan,np.diff(H)]/q
 f['rsi_delta']=np.r_[np.nan,np.diff(R)];f['k_delta']=np.r_[np.nan,np.diff(K)];f['sd60_past']=roll(y,60,'sd',True)
 ar=np.r_[np.nan,np.diff(np.log(a[:,4]))];br=np.r_[np.nan,np.diff(np.log(b[:,4]))];corr=np.full(len(q),np.nan)
 for i in range(60,len(q)):
  aa=ar[i-59:i+1];bb=br[i-59:i+1]
  if np.std(aa)>0 and np.std(bb)>0:corr[i]=np.corrcoef(aa,bb)[0,1]
 f['corr60']=corr
 with np.errstate(divide='ignore',invalid='ignore'):
  for leg,bars in [('a',a),('b',b)]:
   vol=bars[:,5];recent=roll(vol,3);base=np.r_[np.full(3,np.nan),roll(vol[:-3],30)];f['volume_'+leg]=np.where(base>0,recent/base,np.nan)
 f['price_turn_low']=(ret>0)&(np.r_[np.nan,ret[:-1]]<=0);f['price_turn_high']=(ret<0)&(np.r_[np.nan,ret[:-1]]>=0)
 f['cross_up']=(K>D)&(np.r_[False,(K[:-1]<=D[:-1])]);f['cross_down']=(K<D)&(np.r_[False,(K[:-1]>=D[:-1])])
 f['hl20']=np.zeros(len(q),bool);f['lh80']=np.zeros(len(q),bool)
 for t,p in pivots(K).items():
  if p['previous'] is None:continue
  i,v=p['previous'];dist=p['index']-i
  if dist>20:continue
  if p['side']=='low'and v<20-EPS and p['value']<20-EPS and p['value']>v+EPS:f['hl20'][t]=True
  if p['side']=='high'and v>80+EPS and p['value']>80+EPS and p['value']<v-EPS:f['lh80'][t]=True
 f['rsi_div_low']=np.zeros(len(q),bool);f['rsi_div_high']=np.zeros(len(q),bool)
 for t,p in pivots(y,1e-12).items():
  if p['previous'] is None:continue
  i,v=p['previous'];j=p['index']
  if j-i>20 or not(np.isfinite(R[i])and np.isfinite(R[j])):continue
  if p['side']=='low'and p['value']<v-1e-12 and R[j]>R[i]+EPS:f['rsi_div_low'][t]=True
  if p['side']=='high'and p['value']>v+1e-12 and R[j]<R[i]-EPS:f['rsi_div_high'][t]=True
 return a[:,6].astype(np.int64),q,f

COMPLEMENT=['rsi14','k','d','close_stoch14']
SIGNED=['bbz20','cci20','z180','roc1','roc3','roc10','ma5dist','ma20dist','ma50dist','macd','macd_signal','macd_hist','macd_hist_delta','rsi_delta','k_delta']
def orient(f,side):
 out=dict(f)
 if side=='top':
  for k in COMPLEMENT:out[k]=100-f[k]
  for k in SIGNED:out[k]=-f[k]
  out['closepos20']=1-f['closepos20'];out['bb_percent_b']=1-f['bb_percent_b']
 out['price_turn']=f['price_turn_low'if side=='bottom'else'price_turn_high'];out['k_cross_d']=f['cross_up'if side=='bottom'else'cross_down'];out['stoch_hl20']=f['hl20'if side=='bottom'else'lh80'];out['rsi_divergence']=f['rsi_div_low'if side=='bottom'else'rsi_div_high']
 out['macd_recovery']=(out['macd_hist']<0)&(out['macd_hist_delta']>0)
 out['volume_both']=(f['volume_a']+f['volume_b'])/2
 with np.errstate(divide='ignore',invalid='ignore'):out['volume_relative']=f['volume_a']/f['volume_b']if side=='bottom'else f['volume_b']/f['volume_a']
 return out

def outcome(q,sd,i,sign):
 if i+6>=len(q)or not np.isfinite(sd[i])or sd[i]<=0:return None
 for t in range(i+1,i+7):
  v=sign*math.log(q[t]/q[i])
  if v>=.5*sd[i]:return {'success':True,'result':'favourable_first','bars':t-i}
  if v<=-.5*sd[i]:return {'success':False,'result':'adverse_first','bars':t-i}
 return {'success':False,'result':'neither','bars':6}

def predicate(f,spec):
 v=f[spec['field']];known=np.isfinite(v);h=spec['threshold'];op=spec['op']
 hit={'le':lambda:v<=h,'ge':lambda:v>=h,'gt':lambda:v>h,'eq':lambda:v==h}[op]()
 return known&hit

def describe(values):
 v=np.array(values,float);v=v[np.isfinite(v)]
 return {'n':len(v),'median':float(np.median(v))if len(v)else None,'p25':float(np.quantile(v,.25))if len(v)else None,'p75':float(np.quantile(v,.75))if len(v)else None}

def mask(x):return int.from_bytes(np.packbits(np.array(x,dtype=np.uint8),bitorder='little').tobytes(),'little')
def wilson(k,n):
 if not n:return None
 p=k/n;z=1.959963984540054;return (p+z*z/(2*n)-z*math.sqrt((p*(1-p)+z*z/(4*n))/n))/(1+z*z/n)

def main():
 reg=read(P/'registry.json')
 for s in reg['inputs']:assert sha(s['path'])==s['sha256']
 gallery=read(reg['inputs'][0]['path']);datasets={f['id']:read(Path(reg['inputs'][0]['path']).parent/f['file'])for f in gallery['frames']}
 pairs=[];events=[];cohorts={};offsets=reg['fingerprints']['offsets'];feature_names=['rsi14','k','d','bbz20','cci20','close_stoch14','z180','macd_hist','macd_hist_delta','ma5dist','ma20dist','ma50dist','roc1','roc3','roc10','vol10_30','corr60','volume_a','volume_b']
 for frame in gallery['frames']:
  rows={r['symbol']:r for r in datasets[frame['id']]['rows']}
  for pair in frame['pairs']:
   a,b=rows[pair['a']]['bars'],rows[pair['b']]['bars'];times,q,f=features(a,b);offset=int(np.where(np.array(a)[:,0]==pair['formationStartTimestamp'])[0][0]);assert offset>=180 and len(q)-offset==181
   assert np.array_equal(np.diff(times),np.full(len(q)-1,frame['step']))
   item={'id':pair['id'],'frame':frame['id'],'a':pair['a'],'b':pair['b'],'offset':offset,'times':times,'ratio':q,'features':f,'formation':pair['formation']};pairs.append(item)
   for side,gs in [('bottom','low'),('top','high')]:
    ori=orient(f,side);flags={s['id']:predicate(ori,s)for s in reg['combinationSearch']['flags']};selected=[x for x in pair['formation']['confirmedExtrema']if x['side']==gs]
    near={j+d for x in selected for j in [x['extremeIndex']]for d in range(4)if j+d<180}
    cname=frame['id']+'_'+side;co=cohorts.setdefault(cname,{'frame':frame['id'],'side':side,'observations':[]})
    for j in range(180):
     i=offset+j;o=outcome(q,f['sd60_past'],i,1 if side=='bottom'else-1)
     co['observations'].append({'pair':pair['id'],'index':j,'timestamp':int(times[i]),'split':'train'if j<=101 else'later'if 108<=j<=174 else'purged_or_terminal','outcome':o,'nearMajorExtreme':j in near,'flags':[s['id']for s in reg['combinationSearch']['flags']if flags[s['id']][i]]})
    for ex in selected:
     event={'pair':pair['id'],'frame':frame['id'],'side':side,'extremeIndex':ex['extremeIndex'],'extremeTimestamp':ex['extremeTimestamp'],'confirmationTimestamp':ex['confirmationTimestamp'],'confirmationLagBars':ex['confirmationIndex']-ex['extremeIndex'],'snapshots':{},'flagsAtExtreme':None}
     for d in offsets:
      i=offset+ex['extremeIndex']+d
      if i<0 or i>=len(q):event['snapshots'][str(d)]=None;continue
      event['snapshots'][str(d)]={k:float(f[k][i])for k in feature_names};event['snapshots'][str(d)]['flags']=[s['id']for s in reg['combinationSearch']['flags']if flags[s['id']][i]]
     event['flagsAtExtreme']=event['snapshots']['0']['flags'];events.append(event)
 write('features.json',{'registrySha256':sha(P/'registry.json'),'pairs':pairs})
 write('events.json',{'events':events,'eventCount':len(events),'offsets':offsets,'scope':'Retrospective gallery extremes; features themselves use only closed bars through each observation.'})
 write('observations.json',{'cohorts':cohorts,'registrySha256':sha(P/'registry.json')})
 profiles=[]
 for cname,co in cohorts.items():
  ev=[x for x in events if x['frame']==co['frame']and x['side']==co['side']];bg=co['observations']
  preval=[]
  for spec in reg['combinationSearch']['flags']:
   hits=sum(spec['id']in x['flagsAtExtreme']for x in ev);back=sum(spec['id']in x['flags']for x in bg)
   preval.append({'flag':spec['id'],'extremeHits':hits,'extremeCount':len(ev),'extremeRate':hits/len(ev),'backgroundHits':back,'backgroundCount':len(bg),'backgroundRate':back/len(bg),'prevalenceLift':(hits/len(ev))/(back/len(bg))if back else None})
  profiles.append({'cohort':cname,'events':len(ev),'pairs':len({x['pair']for x in ev}),'confirmationLagBars':describe([x['confirmationLagBars']for x in ev]),'indicatorProfiles':{str(d):{k:describe([x['snapshots'][str(d)][k]for x in ev if x['snapshots'][str(d)]is not None])for k in feature_names}for d in offsets},'flagPrevalence':preval})
 write('profiles.json',{'profiles':profiles})
 specs=reg['combinationSearch']['flags'];combs=[]
 for n in [1,2,3,4]:
  for ids in itertools.combinations(range(len(specs)),n):
   fam=[specs[i]['family']for i in ids]
   if len(set(fam))<n or (n>1 and'Location'not in fam):continue
   combs.append(ids)
 combinations=[];winners=[]
 for cname,co in cohorts.items():
  subsets={s:[x for x in co['observations']if x['split']==s and x['outcome']is not None]for s in ['train','later']};packed={}
  for split,rows in subsets.items():
   packed[split]={'flags':[mask([spec['id']in row['flags']for row in rows])for spec in specs],'success':mask([row['outcome']['success']for row in rows]),'near':mask([row['nearMajorExtreme']for row in rows]),'pairs':{pair:mask([r['pair']==pair for r in rows])for pair in sorted({r['pair']for r in rows})}}
  candidates=[]
  for ids in combs:
   item={'cohort':cname,'flags':[specs[i]['id']for i in ids],'size':len(ids)}
   for split,rows in subsets.items():
    bits=packed[split]['flags'][ids[0]]
    for i in ids[1:]:bits &=packed[split]['flags'][i]
    calls=bits.bit_count();good=(bits&packed[split]['success']).bit_count();near=(bits&packed[split]['near']).bit_count();paircount=sum(bool(bits&m)for m in packed[split]['pairs'].values());base=packed[split]['success'].bit_count()/len(rows)
    item[split]={'calls':calls,'successes':good,'successRate':good/calls if calls else None,'distinctPairs':paircount,'baseRate':base,'lift':(good/calls)/base if calls else None,'majorExtremeProximityCalls':near,'majorExtremeProximityRate':near/calls if calls else None,'wilsonRankingLower':wilson(good,calls),'backgroundBars':len(rows)}
   item['eligibleTrainWinner']=item['train']['calls']>=20 and item['train']['distinctPairs']>=8
   combinations.append(item)
   if item['eligibleTrainWinner']:candidates.append(item)
  candidates.sort(key=lambda x:(-x['train']['wilsonRankingLower'],-x['train']['successRate'],-x['train']['calls'],x['size'],x['flags']))
  assert candidates
  winner=dict(candidates[0]);winner['trainRank']=1;winner['selectionUsesLaterOutcomes']=False;winner['episodes']={}
  for split,rows in subsets.items():
   episodes=[]
   for pair in sorted({r['pair']for r in rows}):
    next_index=-1;was_active=False
    for row in [r for r in rows if r['pair']==pair]:
     active=all(flag in row['flags']for flag in winner['flags']);edge=active and not was_active;was_active=active
     if edge and row['index']>=next_index:
      episodes.append({'pair':pair,'index':row['index'],'timestamp':row['timestamp'],'success':row['outcome']['success'],'outcome':row['outcome']['result']});next_index=row['index']+6
   winner['episodes'][split]={'calls':len(episodes),'successes':sum(x['success']for x in episodes),'successRate':sum(x['success']for x in episodes)/len(episodes)if episodes else None,'distinctPairs':len({x['pair']for x in episodes}),'rows':episodes}
  winners.append(winner);print(cname,'searched',len(combs),'winner',winner['flags'],'train',winner['train']['successRate'],'later',winner['later']['successRate'],flush=True)
 write('combinations.json',{'combinationsPerCohort':len(combs),'cohorts':4,'rows':combinations,'winnerPolicy':reg['combinationSearch']['eligibleWinner']})
 write('winners.json',{'status':'TRAIN_SELECTED_CONDITIONAL_PRICE_DIAGNOSTIC_NOT_PNL','winners':winners,'registrySha256':sha(P/'registry.json'),'combinationsSha256':sha(P/'combinations.json')})
 write('summary.json',{'createdAt':datetime.now(timezone.utc).isoformat(),'pairs':len(pairs),'distinctPairs':len({x['id']for x in pairs}),'events':len(events),'predicates':len(specs),'combinationsPerCohort':len(combs),'totalCombinationCases':len(combinations),'featureFields':len(pairs[0]['features']),'fingerprintProfiles':profiles,'winners':[ {k:v for k,v in w.items()if k!='episodes'}for w in winners],'inputsUnchanged':all(sha(s['path'])==s['sha256']for s in reg['inputs'])})
 for s in reg['inputs']:assert sha(s['path'])==s['sha256']
 print('COMPLETE',len(pairs),'pair/timeframes',len(events),'events',len(combinations),'combinations',flush=True)

if __name__=='__main__':main()
