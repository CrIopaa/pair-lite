"""Isolated descriptive setup engines. No private exchange API, trades or tracker writes."""
from pathlib import Path
import json,math,sys,datetime,hashlib,importlib.util,subprocess
import numpy as np
from acquire import read,write,utc,DAY,FOUR,HOUR
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent
spec=importlib.util.spec_from_file_location('atlas',PROJECT/'research/refinement/round9_turn_fingerprints/study.py');AT=importlib.util.module_from_spec(spec);spec.loader.exec_module(AT)
def clean(x):return AT.clean(x)
def finite(x):return isinstance(x,(int,float,np.number))and math.isfinite(float(x))
def positive(x):return finite(x)and x>0
def bound(v,a,b):return min(b,max(a,v))
def geometry(x,current,strict=True,ultra=False):
 x=np.asarray(x,float);n=len(x)
 if n<3 or not np.isfinite(x).all()or not finite(current):return None
 lo,hi=np.quantile(x,[.1,.9]);w=hi-lo
 if w<=0:return None
 t=np.arange(n)-(n-1)/2;drift=abs((x-x.mean())@t/(t@t)*(n-1))/w
 parts=np.array([np.quantile(x[k*n//3:(k+1)*n//3],[.1,.9])for k in range(3)]);shift=max(np.ptp(parts[:,0]),np.ptp(parts[:,1]))/w;widths=(parts[:,1]-parts[:,0])/w
 states=[]
 for i,v in enumerate(x):
  side=1 if v>=lo+.8*w else -1 if v<=lo+.2*w else 0
  if side and(not states or states[-1][1]!=side):states.append((i,side))
 lows=[];highs=[]
 for k in range(1,len(states)-1):
  i,s=states[k];v=x[i:states[k+1][0]];(lows if s<0 else highs).append(float(min(v)if s<0 else max(v)))
 mad=max(float(np.median(abs(np.array(v)-np.median(v)))/w)for v in [lows,highs])if lows and highs else math.inf
 dmax,smax,sw,each,mmax,out=(.2,.2,16,6,.10,.05)if ultra else(.35,.35,8,3,.15,.1)if strict else(.5,.45,5,2,.22,.25)
 loc=(current-lo)/w;reasons=[]
 for hit,name in [(w<math.log(1.1),'Band narrower than10%'),(drift>dmax,'Drift'),(shift>smax,'Boundary shift'),(not np.all((widths>=.45)&(widths<=1.8)),'Changing width'),(len(states)-1<sw,'Too few transitions'),(min(len(lows),len(highs))<each,'Too few extrema'),(mad>mmax,'Irregular extrema'),(not -out<=loc<=1+out,'Latest outside')]:
  if hit:reasons.append(name)
 score=30*(1-bound(drift/dmax,0,1))+25*(1-bound(shift/smax,0,1))+20*min((len(states)-1)/16,1)+15*(1-bound(mad/mmax,0,1))+10*min(min(len(lows),len(highs))/6,1)
 return clean({'pass':not reasons,'reasons':reasons,'loLog':lo,'hiLog':hi,'low':math.exp(lo),'high':math.exp(hi),'widthLog':w,'drift':drift,'shift':shift,'thirdWidths':widths,'transitions':len(states)-1,'lows':len(lows),'highs':len(highs),'mad':mad,'logPosition':loc,'score':score})
def osc(x,current):
 x=np.asarray(x,float);n=len(x)
 if n!=180 or not np.isfinite(x).all():return None
 mu=x.mean();ss=sum((x-mu)**2);sd=math.sqrt(ss/(n-1))
 if not sd>0:return None
 a=x[:-1];b=np.diff(x);aa=a-a.mean();bb=b-b.mean();szz=aa@aa
 if szz<=0:return None
 beta=(aa@bb)/szz;rss=max(1e-30,bb@bb-beta*(aa@bb));df=beta/math.sqrt(rss/(len(a)-2)/szz)
 t=np.arange(n)-(n-1)/2;stx=t@(x-mu);r2=stx*stx/((t@t)*ss);drift=abs(stx/(t@t)*(n-1))/sd
 states=[]
 for i,v in enumerate(x):
  side=1 if v>=mu+sd else -1 if v<=mu-sd else 0
  if side and(not states or states[-1][1]!=side):states.append((i,side))
 low=[];high=[]
 for k in range(1,len(states)-1):
  i,s=states[k];y=x[i:states[k+1][0]];(low if s<0 else high).append(float(min(y)if s<0 else max(y)))
 both=sum(min(x[k*60:(k+1)*60])<=mu-.8*sd and max(x[k*60:(k+1)*60])>=mu+.8*sd for k in range(3))
 gate=.03<=sd<=.6 and df<=-2.86 and r2<.5 and drift<=.7 and len(states)-1>=5 and both==3 and min(len(low),len(high))>=2
 env=bool(low and high and min(low)-.5*sd<=current<=max(high)+.5*sd)
 return clean({'pass':bool(gate and env),'formationPass':bool(gate),'mu':mu,'sd':sd,'df':df,'r2':r2,'drift':drift,'transitions':len(states)-1,'thirds':both,'lows':len(low),'highs':len(high),'low':math.exp(np.mean(low))if low else None,'high':math.exp(np.mean(high))if high else None,'currentZ':(current-mu)/sd,'insideEnvelope':env})
def latest_fingerprint(a,b,side='bottom'):
 # Same round9 formulas at the latest bar, without recalculating unused historical feature arrays.
 a=np.asarray(a,float);b=np.asarray(b,float);q=a[:,4]/b[:,4];y=np.log(q);ret=np.diff(y);R=AT.rsi(q);fast=[]
 for i in range(len(q)-4,len(q)):
  w=R[i-13:i+1];mn,mx=np.min(w),np.max(w);fast.append(float(np.clip(100*(R[i]-mn)/(mx-mn),0,100))if np.isfinite(w).all()and mx>mn else math.nan)
 K=float(np.mean(fast[-3:]));Kprev=float(np.mean(fast[-4:-1]));priorSD=np.std(y[-181:-1],ddof=1)if len(y)>=181 else math.nan;mean20=np.mean(q[-20:]);pop20=np.std(q[-20:]);mad=np.mean(abs(q[-20:]-mean20));rv30=np.std(ret[-30:],ddof=1);aa=np.diff(np.log(a[:,4]))[-60:];bb=np.diff(np.log(b[:,4]))[-60:]
 f={'rsi14':float(R[-1]),'k':K,'k_delta':K-Kprev,'bbz20':(q[-1]-mean20)/pop20 if pop20>0 else math.nan,'cci20':(q[-1]-mean20)/(.015*mad)if mad>0 else math.nan,'z180':(y[-1]-np.mean(y[-181:-1]))/priorSD if priorSD>0 else math.nan,'vol10_30':np.std(ret[-10:],ddof=1)/rv30 if rv30>0 else math.nan,'ma50slope5_sd':abs(math.log(np.mean(q[-50:])/np.mean(q[-55:-5])))/priorSD if priorSD>0 else math.nan,'corr60':np.corrcoef(aa,bb)[0,1]if len(aa)==60 and np.std(aa)>0 and np.std(bb)>0 else math.nan,'volume_both':(np.mean(a[-3:,5])/np.mean(a[-33:-3,5])+np.mean(b[-3:,5])/np.mean(b[-33:-3,5]))/2 if min(np.mean(a[-33:-3,5]),np.mean(b[-33:-3,5]))>0 else math.nan}
 if side=='top':
  f['rsi14']=100-f['rsi14'];f['k']=100-f['k']
  for k in ['k_delta','bbz20','cci20','z180']:f[k]=-f[k]
 return f

class Search:
 def __init__(self,snapshot,frame='daily'):
  self.path=Path(snapshot);self.meta=read(self.path/'snapshot.json');self.public=read(self.path/'public.json');self.frame=frame;self.info={x['symbol']:x for x in self.public['data']['info']['symbols']};self.marks={x['symbol']:x for x in self.public['data']['marks']};self.book={x['symbol']:x for x in self.public['data']['book']};self.fund={x['symbol']:x for x in self.public['data']['funding']};self.daily=read(self.path/'daily.json');self.dmap={r['symbol']:r for r in self.daily['rows']if r['complete']};self.ds=self.daily if frame=='daily'else read(self.path/(frame+'.json'));self.cut=self.ds['cutoffExclusive'];self.step=self.ds['step'];self.rows=[]
  for r in self.ds['rows']:
   if not r['complete']:continue
   bars=r['bars']
   if not bars or any(b[0]!=self.cut-(len(bars)-i)*self.step or b[6]!=b[0]+self.step-1 or not positive(b[4])or not finite(b[5])for i,b in enumerate(bars)):continue
   if self.info.get(r['symbol'],{}).get('status')!='TRADING':continue
   self.rows.append(r)
  self.rows.sort(key=lambda x:x['symbol']);self.by={r['symbol']:r for r in self.rows};self.counts={};self.warnings=[];self.hourlyMap=None;self.hourlyCut=None
 def context(self,L,S):
  legs=[];carry=0;known=True
  for s,sign in [(L,-1),(S,1)]:
   m=self.marks.get(s,{});bo=self.book.get(s,{});f=self.fund.get(s,{});rate=float(m.get('lastFundingRate','nan'));interval=f.get('fundingIntervalHours',8);bid=float(bo.get('bidPrice','nan'));ask=float(bo.get('askPrice','nan'));mt=m.get('time',0);bt=bo.get('time',0);now=self.meta['serverTime'];fresh=abs(mt-now)<=120000;bfresh=abs(bt-now)<=120000
   spread=100*(ask-bid)/((ask+bid)/2)if 0<bid<=ask and bfresh else None;v=self.dmap.get(s,{}).get('bars',[]);volume=float(np.mean([b[5]for b in v[-30:]]))if len(v)>=30 else None
   if finite(rate)and interval>0 and fresh:carry+=sign*100*rate*24/interval
   else:known=False
   legs.append({'symbol':s,'mark':float(m['markPrice'])if fresh and positive(float(m.get('markPrice','nan')))else None,'markTime':mt,'spreadPct':spread,'volume30USDT':volume,'fundingRate':rate if finite(rate)else None,'fundingIntervalHours':interval,'cadence':'adjusted'if s in self.fund else'documented default8h'})
  a,b=legs;sync=all(positive(x['mark'])for x in legs)and abs(a['markTime']-b['markTime'])<=15000
  return {'legs':legs,'currentRatio':a['mark']/b['mark']if sync else None,'indicativeCarryDailyPctOfOneLeg':carry if known else None,'quoteAsOf':self.meta['serverTime'],'fundingMeaning':'Last indicative rates held unchanged, not actual future funding or seven-day entry eligibility.'}
 def row(self,L,S,metrics,score=0,**kw):return {'long':L,'short':S,'pair':L[:-4]+'/'+S[:-4],'frame':self.frame,'metrics':clean(metrics),'score':float(score),**kw}
 def series(self,L,S):
  a,b=self.by[L]['bars'],self.by[S]['bars'];n=min(len(a),len(b));a,b=a[-n:],b[-n:];assert [v[0]for v in a]==[v[0]for v in b];return np.log(np.array([v[4]for v in a])/np.array([v[4]for v in b]))
 def ranges(self,strict=True,windows=(90,180,360,720),ultra=False):
  cache=self.path/('computed-'+self.frame+'-range-'+('ultra'if ultra else'strict'if strict else'broad')+'-'+','.join(map(str,windows))+'.json')
  if cache.exists():return read(cache)
  out=[];counts={}
  for n in windows:
   rs=[r for r in self.rows if len(r['bars'])>=n+1];counts[str(n)]={'contracts':len(rs),'pairComparisons':len(rs)*(len(rs)-1)//2,'matches':0};logs=np.log(np.array([[b[4]for b in r['bars'][-n-1:]]for r in rs]))if rs else np.empty((0,n+1));t=np.arange(n)-(n-1)/2;dmax,smax=(.2,.2)if ultra else(.35,.35)if strict else(.5,.45)
   for i,A in enumerate(rs[:-1]):
    z=logs[i]-logs[i+1:];x=z[:,:-1];lo,hi=np.quantile(x,[.1,.9],axis=1);w=hi-lo;safe=np.where(w>0,w,1);drift=np.abs((x-x.mean(axis=1,keepdims=True))@t/(t@t)*(n-1))/safe;p=np.array([np.quantile(x[:,k*n//3:(k+1)*n//3],[.1,.9],axis=1)for k in range(3)]);shift=np.maximum(np.ptp(p[:,0,:],axis=0),np.ptp(p[:,1,:],axis=0))/safe;widths=(p[:,1,:]-p[:,0,:])/safe
    eligible=(w>=math.log(1.1))&(drift<=dmax)&(shift<=smax)&np.all((widths>=.45)&(widths<=1.8),axis=0)
    for j in np.flatnonzero(eligible):
     B=rs[i+1+int(j)];g=geometry(x[j],z[j,-1],strict,ultra)
     if g and g['pass']:out.append({'a':A['symbol'],'b':B['symbol'],'bars':n,**g});counts[str(n)]['matches']+=1
  result={'rows':out,'counts':counts};write(cache,result);return result
 def oscillators(self,scope='broad',persistent=False):
  cache=self.path/('computed-'+self.frame+'-osc-'+scope+'-'+str(persistent)+'.json')
  if cache.exists():return read(cache)
  cutday=self.cut//DAY-1;eligible=set(self.by)
  if scope=='liquid':
   ranked=sorted([s for s in self.dmap if (self.daily['cutoffExclusive']//DAY-1)-self.info[s]['onboardDate']//DAY>=95 and len(self.dmap[s]['bars'])>=30],key=lambda s:(-sum(b[5]for b in self.dmap[s]['bars'][-30:]),s));eligible&=set(ranked[:150])
  rs=[r for r in self.rows if r['symbol']in eligible and cutday-self.info[r['symbol']]['onboardDate']//DAY>=365 and len(r['bars'])>=181];out=[];counts={'contracts':len(rs),'pairComparisons':len(rs)*(len(rs)-1)//2};logs=np.log(np.array([[b[4]for b in r['bars'][-181:]]for r in rs]))if rs else np.empty((0,181));t=np.arange(180)-89.5
  for i,A in enumerate(rs[:-1]):
   z=logs[i]-logs[i+1:];x=z[:,:-1];mu=x.mean(axis=1);ss=((x-mu[:,None])**2).sum(axis=1);sd=np.sqrt(ss/179);stx=(x-mu[:,None])@t
   with np.errstate(divide='ignore',invalid='ignore'):
    drift=abs(stx/(t@t)*179)/sd;r2=stx**2/((t@t)*ss);a=x[:,:-1];b=np.diff(x,axis=1);aa=a-a.mean(axis=1,keepdims=True);bb=b-b.mean(axis=1,keepdims=True);szz=(aa*aa).sum(axis=1);szy=(aa*bb).sum(axis=1);beta=szy/szz;rss=np.maximum(1e-30,(bb*bb).sum(axis=1)-beta*szy);df=beta/np.sqrt(rss/177/szz)
   good=(sd>=.03)&(sd<=.6)&(drift<=.7)&(r2<.5)&(df<=-2.86)
   for j in np.flatnonzero(good):
    B=rs[i+1+int(j)];g=osc(x[j],z[j,-1])
    if not g or not g['pass']:continue
    xx=self.series(A['symbol'],B['symbol']);prev=osc(xx[-361:-181],xx[-182])if len(xx)>=361 else None
    if persistent and(not prev or not prev['formationPass']):continue
    out.append({'a':A['symbol'],'b':B['symbol'],'geometry':g,'previousPass':prev['formationPass']if prev else None,'bars':180})
  out.sort(key=lambda r:(-r['geometry']['transitions'],r['geometry']['drift'],r['a'],r['b']));result={'rows':out,'counts':counts};write(cache,result);return result
 def range_rows(self,definition):
  e=definition['engine'];ultra=e=='ultra';n=definition.get('days',[180,360]if not definition.get('strict',True)else[90,180,360,720]);windows=[n]if isinstance(n,int)else n;strict=definition.get('strict',True);base=self.ranges(strict,windows,ultra);self.counts=base['counts'];out=[]
  for g in base['rows']:
   A,B=g['a'],g['b'];x=self.series(A,B);ctx=self.context(A,B);cur=math.log(ctx['currentRatio'])if ctx['currentRatio']else float(x[-1]);pos=(cur-g['loLog'])/g['widthLog'];dir=1 if pos<=.5 else -1;L,S=(A,B)if dir==1 else(B,A);loc=pos if dir==1 else 1-pos
   if e=='edge'and not -.1<=loc<=definition.get('edge',.25):continue
   if ultra:
    nn=g['bars'];prev=geometry(x[-2*nn-1:-nn-1],x[-nn-2],True,True)if len(x)>=2*nn+1 else None
    if not prev or not prev['pass']:continue
    if max(abs(prev['loLog']-g['loLog']),abs(prev['hiLog']-g['hiLog']))>.2*g['widthLog']:continue
   out.append(self.row(L,S,{'formationBars':g['bars'],'daysCovered':g['bars']*self.step/DAY,'locationPct':100*loc,'bandLow':g['low']if dir==1 else 1/g['high'],'bandHigh':g['high']if dir==1 else 1/g['low'],'driftWidths':g['drift'],'boundaryShiftWidths':g['shift'],'transitions':g['transitions'],'confirmedLows':g['lows'],'confirmedHighs':g['highs'],'extremaMADWidths':g['mad']},g['score'],canonicalA=A,canonicalB=B,geometry=g,stage='Numerical range; inspect chart'))
  return self.dedupe(out)
 def dedupe(self,rows):
  by={}
  for p in rows:
   k=(p['long'],p['short'])
   if k not in by or p['metrics'].get('formationBars',0)>by[k]['metrics'].get('formationBars',0):by[k]=p
  return sorted(by.values(),key=lambda p:(-p['score'],p['pair']))
 def reversal(self,confirmed=False):
  if self.frame!='daily':self.warnings.append('Timeframe adaptation: context uses180/360 bars of selected frame; timing uses the same frame. The original uses daily context with4h timing.')
  timing=self if self.frame!='daily'else Search(self.path,'four');out=[];base=self.ranges(False,[180,360]);self.counts=base['counts']
  for g in base['rows']:
   A,B=g['a'],g['b']
   if A not in timing.by or B not in timing.by:continue
   z=timing.series(A,B)
   for direction in [1,-1]:
    y=z*direction;lo=g['loLog']if direction==1 else -g['hiLog'];w=g['widthLog'];pos=(y[-1]-lo)/w;start=len(y)-18;mini=min(y[start:]);idx=start+int(np.flatnonzero(y[start:]==mini)[-1]);age=len(y)-1-idx;reb=(y[-1]-mini)/w
    if not(.10<=pos<=.42 and(mini-lo)/w<=.15 and 2<=age<=15 and reb>=.08 and y[-1]>y[-4]and y[-1]>=y[-2]-.01*w and y[-1]>=np.mean(y[-4:-1])):continue
    pre=y[-1]>max(y[idx-3:idx]);higher=any(y[k]<y[k-1]and y[k]<y[k+1]and y[k]-mini>=.015*w and y[-1]>max(y[idx+1:k])for k in range(idx+2,len(y)-1));conf=bool(pre or higher)
    if confirmed and not conf:continue
    L,S=(A,B)if direction==1 else(B,A);score=.55*g['score']+20*conf+15*min((y[-1]-y[-4])/w/.15,1)+10*(.5-pos)/.4
    out.append(self.row(L,S,{'formationBars':g['bars'],'locationPct':pos*100,'lowAgeTimingBars':age,'reboundBandPct':reb*100,'structureConfirmed':conf,'timingFrame':timing.frame,'timingLastClose':timing.cut-1},score,geometry=g,stage='Structure confirmed'if conf else'Early turn'))
  return self.dedupe(out)
 def extreme(self):
  timing=self if self.frame!='daily'else Search(self.path,'four');out=[];rs=[r for r in self.rows if len(r['bars'])>=95 and r['symbol']in timing.by and len(timing.by[r['symbol']]['bars'])>=24];self.counts={'contracts':len(rs),'pairComparisons':len(rs)*(len(rs)-1)//2}
  for i,A in enumerate(rs[:-1]):
   for B in rs[i+1:]:
    x=self.series(A['symbol'],B['symbol']);z=timing.series(A['symbol'],B['symbol'])[-24:]
    for n in [180,90]:
     if len(x)<n+5:continue
     base=x[-n-5:-5];mu=base.mean();sd=base.std(ddof=1)
     if sd<=0:continue
     for d in [1,-1]:
      y=z*d;m=mu*d;idx=len(y)-18+int(np.flatnonzero(y[-18:]==min(y[-18:]))[-1]);mini=y[idx];gap=m-mini;gapNow=m-y[-1];age=len(y)-1-idx;reb=y[-1]-mini;recovery=reb/gap if gap>0 else 0
      if not(gap>=2.5*sd and gap>=math.log(1.25)and np.mean(base*d<=mini)<=.025 and gapNow>=1.5*sd and gapNow>=math.log(1.1)and 2<=age<=15 and reb>=.2*sd and .05<=recovery<=.4 and y[-1]>y[-4]and y[-1]>=y[-2]-.02*sd and y[-1]>=np.mean(y[-4:-1])):continue
      pre=y[-1]>max(y[idx-3:idx]);higher=any(y[k]<y[k-1]and y[k]<y[k+1]and y[k]-mini>=.05*sd and y[-1]>max(y[idx+1:k])for k in range(idx+2,len(y)-1))
      if not(pre or higher):continue
      L,S=(A['symbol'],B['symbol'])if d==1 else(B['symbol'],A['symbol']);score=35*min(gap/math.log(2),1)+25*min(recovery/.3,1)+20*min((y[-1]-y[-4])/sd/.2,1)+20*higher
      out.append(self.row(L,S,{'formationBars':n,'extremeSD':gap/sd,'currentGapSD':gapNow/sd,'recoveryPctOfLogGap':recovery*100,'lowAgeTimingBars':age,'structureConfirmed':True,'timingFrame':timing.frame},score,stage='Extreme structure turn; range not required'))
  return self.dedupe(out)
 def pump(self,definition):
  # Selected timeframe changes bar-count setup windows;14daily bars remains the original.
  c={};out=[]
  for r in self.rows:
   bs=r['bars'];s=r['symbol']
   if len(bs)<18:continue
   cur=self.context(s,s)['legs'][0]['mark']
   if not cur:continue
   close=np.array([b[4]for b in bs]);c[s]={'return':cur/close[-15]-1,'pump':max(close[k]/close[k-3]-1 for k in range(len(close)-14,len(close))),'fade':1-cur/max(cur,max(close[-14:])),'base':close[-15],'current':cur}
  self.counts={'contracts':len(c),'orientedPairs':len(c)*(len(c)-1)}
  for S,s in c.items():
   if not(s['pump']>=definition.get('pumpMinimum',.3)and s['return']>=.15 and .05<=s['fade']<=.45):continue
   for L,l in c.items():
    if L==S or l['return']>.2 or s['return']-l['return']<.2:continue
    x=self.series(L,S);q=l['current']/s['current'];fall=q/(l['base']/s['base'])-1;rebound=q/math.exp(min(x[-14:]))-1
    if fall>-.2 or rebound<.05:continue
    tim=self.timing(L,S);both=tim.get('long4hPct',0)>0 and tim.get('short4hPricePct',0)<0
    if definition.get('bothGreen')and not both:continue
    out.append(self.row(L,S,{'lookbackBars':14,'long14BarPct':l['return']*100,'short14BarPct':s['return']*100,'shortMax3BarPumpPct':s['pump']*100,'shortFadePct':s['fade']*100,'outperformancePP':(s['return']-l['return'])*100,'ratioFallPct':fall*100,'ratioReboundPct':rebound*100,**tim,'bothGreen4h':both},-(s['return']-l['return']+rebound),stage='Divergence recovery; intact range not required'))
  return sorted(out,key=lambda p:(-p['score'],p['pair']))
 def timing(self,L,S):
  try:
   if self.hourlyMap is None:
    h=read(self.path/'hourly.json');self.hourlyMap={r['symbol']:r for r in h['rows']if r['complete']};self.hourlyCut=h['cutoffExclusive']
   hm=self.hourlyMap;a,b=hm[L]['bars'],hm[S]['bars'];assert len(a)>=25 and len(b)>=25;aa=np.array([v[4]for v in a[-25:]]);bb=np.array([v[4]for v in b[-25:]]);return {'ratio4hPct':100*((aa[-1]/bb[-1])/(aa[-5]/bb[-5])-1),'ratio24hPct':100*((aa[-1]/bb[-1])/(aa[-25]/bb[-25])-1),'long4hPct':100*(aa[-1]/aa[-5]-1),'short4hPricePct':100*(bb[-1]/bb[-5]-1),'hourlyCutoff':self.hourlyCut}
  except (KeyError,FileNotFoundError,AssertionError):return {'timingUnavailable':True}
 def moderate(self):
  out=[];base=self.ranges(True,[90,180,360]);self.counts=base['counts']
  for g in base['rows']:
   for d in [1,-1]:
    L,S=(g['a'],g['b'])if d==1 else(g['b'],g['a']);ctx=self.context(L,S);q=ctx['currentRatio'];a,b=self.by[L]['bars'],self.by[S]['bars'];lo,hi=(g['low'],g['high'])if d==1 else(1/g['high'],1/g['low'])
    if not q or len(a)<15 or len(b)<15:continue
    loc=(q-lo)/(hi-lo);lr=ctx['legs'][0]['mark']/a[-15][4]-1;sr=ctx['legs'][1]['mark']/b[-15][4]-1;gap=sr-lr;tim=self.timing(L,S);carry=ctx['indicativeCarryDailyPctOfOneLeg']
    practical=all(x['volume30USDT']is not None and x['volume30USDT']>=2e6 and x['spreadPct']is not None and x['spreadPct']<=.15 for x in ctx['legs'])and carry is not None and carry>=-.1
    if not(0<=loc<=.25 and -.3<=lr<=.1 and -.1<=sr<=.3 and .05<=gap<=.3 and practical):continue
    turn=not tim.get('timingUnavailable')and .5<=tim['ratio4hPct']<=10 and 0<=tim['ratio24hPct']<=15
    out.append(self.row(L,S,{'formationBars':g['bars'],'locationPct':loc*100,'long14BarPct':lr*100,'short14BarPct':sr*100,'outperformancePP':gap*100,'timingPass':turn,**tim},g['score'],geometry=g,stage='Timing passes'if turn else'Watch: waiting for timing'))
  return self.dedupe(out)
 def fingerprints(self,definition):
  cohort=definition['cohort'];side=cohort.split('_')[1];base=self.oscillators('broad');out=[];self.counts=base['counts'];reg=read(PROJECT/'research/refinement/round9_turn_fingerprints/registry.json');winner=next(w for w in read(PROJECT/'research/refinement/round9_turn_fingerprints/winners.json')['winners']if w['cohort']==cohort);specs={s['id']:s for s in reg['combinationSearch']['flags']}
  for p in base['rows']:
   A,B=p['a'],p['b'];a,b=self.by[A]['bars'],self.by[B]['bars'];n=min(len(a),len(b));f=latest_fingerprint(a[-n:],b[-n:],side);hit=all(finite(f.get(specs[k]['field'])) and {'le':lambda v,h:v<=h,'ge':lambda v,h:v>=h,'gt':lambda v,h:v>h,'eq':lambda v,h:v==h}[specs[k]['op']](f[specs[k]['field']],specs[k]['threshold']) for k in winner['flags'])
   if not hit:continue
   L,S=(A,B)if side=='bottom'else(B,A);out.append(self.row(L,S,{k:clean(f[specs[k]['field']])for k in winner['flags']},p['geometry']['transitions'],stage='Indicator combination; not a trade win probability'))
  return out
 def confluence(self):
  base=self.ranges(False,[180,360]);self.counts=base['counts'];groups={}
  for p in base['rows']:groups.setdefault((p['a'],p['b']),[]).append(p)
  votes={}
  for (A,B),gs in groups.items():
   q=self.context(A,B)['currentRatio']
   if not q:continue
   locs=[(math.log(q)-g['loLog'])/g['widthLog']for g in sorted(gs,key=lambda g:-g['bars'])];sides=[1 if 0<=v<=1/3 else -1 if 2/3<=v<=1 else 0 for v in locs]
   if 1 in sides and -1 in sides:continue
   side=sides[0]
   if side==0:continue
   for token,sg in [(A,side),(B,-side)]:
    r=votes.setdefault(token,{'longVotes':0,'shortVotes':0,'counterparts':[]});r['longVotes'if sg==1 else'shortVotes']+=1;r['counterparts'].append({'other':B if token==A else A,'vote':'long'if sg==1 else'short'})
  return [self.row(s,s,{'longVotes':v['longVotes'],'shortVotes':v['shortVotes'],'netVotes':v['longVotes']-v['shortVotes'],'counterparts':v['counterparts']},abs(v['longVotes']-v['shortVotes']),stage='Relative coin bias, dependent votes')for s,v in sorted(votes.items(),key=lambda kv:-abs(kv[1]['longVotes']-kv[1]['shortVotes']))]
 def consistent(self):
  v=self.ranges(True,[90,180,360,720]);self.counts=v['counts'];groups={};out=[]
  for g in v['rows']:groups.setdefault((g['a'],g['b']),[]).append(g)
  for (A,B),gg in groups.items():
   g=max(gg,key=lambda p:(p['bars'],p['score']));x=self.series(A,B);ctx=self.context(A,B);cur=math.log(ctx['currentRatio'])if ctx['currentRatio']else float(x[-1]);pos=(cur-g['loLog'])/g['widthLog'];d=1 if pos<=.5 else -1;L,S=(A,B)if d==1 else(B,A);n=g['bars'];prev=geometry(x[-2*n-1:-n-1],x[-n-1],True)if len(x)>=2*n+1 else None
   directions=[1 if(cur-h['loLog'])/h['widthLog']<=.5 else -1 for h in gg];conflict=len(set(directions))>1
   out.append(self.row(L,S,{'formationBars':n,'daysCovered':n*self.step/DAY,'passingWindows':[p['bars']for p in sorted(gg,key=lambda p:p['bars'])],'matchingWindows':len(gg),'locationPct':100*(pos if d==1 else 1-pos),'driftWidths':g['drift'],'boundaryShiftWidths':g['shift'],'transitions':g['transitions'],'confirmedLows':g['lows'],'confirmedHighs':g['highs'],'extremaMADWidths':g['mad'],'priorWindowPass':prev['pass']if prev else None,'horizonDirectionsConflict':conflict},100*len(gg)+g['score'],geometry=g,stage='Strict range; conflicting horizon directions'if conflict else'Strict range; current mark outside fitted band'if not 0<=pos<=1 else'Strict range; inspect chart'))
  return sorted(out,key=lambda p:(-p['metrics']['matchingWindows'],-p['metrics']['formationBars'],-p['score'],p['pair']))

 def daily_trend(self):
  from daily_trend import daily_metrics,daily_leg_quality
  D=self if self.frame=='daily'else Search(self.path,'daily');eligible=[];out=[];bad={'insufficientDailyHistory':0,'dailyWickRejected':0,'practicalRejected':0};quality={}
  self.warnings.append('Daily structural trend is always measured on180/360 DAILY observations. The dropdown changes chart detail only, never compresses the daily evidence. This template-guided screen is descriptive; ratio gains are not fixed-quantity net P&L or future-profit forecasts.')
  self.warnings.append('The DOGE/SHELL reference itself had substantial pullbacks. Upward structure does not mean every daily candle is green. Tail limits inspect each leg over the latest30completed daily candles; synchronous pair intrabar wicks remain unknown.')
  for r in D.rows:
   sym=r['symbol'];q,reasons=daily_leg_quality(r['bars'])
   if q is None:bad['insufficientDailyHistory']+=1;continue
   if reasons:bad['dailyWickRejected']+=1;continue
   ctx=D.context(sym,sym);leg=ctx['legs'][0]
   if not positive(leg['mark'])or leg['volume30USDT']is None or leg['volume30USDT']<2e6 or leg['spreadPct']is None or leg['spreadPct']>.15:bad['practicalRejected']+=1;continue
   eligible.append(r);quality[sym]=q
  self.counts={'dailyCoverage':{'completeContracts':len(D.rows),'screenableContracts':len(eligible),**bad},'pipeline':{'unorderedDailyPairs':len(eligible)*(len(eligible)-1)//2,'dailyTrendPrefilterPassed':0,'bothDailyWindowsPassed':0,'currentHealthPassed':0,'carryPassed':0}}
  counts=self.counts['pipeline'];logs=np.log(np.array([[v[4]for v in r['bars'][-361:]]for r in eligible]))if eligible else np.empty((0,361))
  for i,A in enumerate(eligible[:-1]):
   z=logs[i]-logs[i+1:];direction=np.where(z[:,-1]>=z[:,0],1,-1);y=z*direction[:,None];good=np.ones(len(y),dtype=bool)
   for n,mingain in [(180,.15),(360,.25)]:
    v=y[:,-n-1:];t=np.arange(n+1)-n/2;center=v-v.mean(axis=1,keepdims=True);ss=(center*center).sum(axis=1);cov=center@t
    with np.errstate(divide='ignore',invalid='ignore'):r2=cov*cov/((t@t)*ss)
    good&=(v[:,-1]-v[:,0]>=math.log1p(mingain))&(cov>0)&(r2>=.60)
   counts['dailyTrendPrefilterPassed']+=int(sum(good))
   for j in np.flatnonzero(good):
    B=eligible[i+1+int(j)];L,S=(A['symbol'],B['symbol'])if direction[j]>0 else(B['symbol'],A['symbol']);m,reasons=daily_metrics(y[j])
    window_rejections=[r for r in reasons if r.startswith(('180d:','360d:'))]
    if window_rejections:continue
    counts['bothDailyWindowsPassed']+=1
    if reasons:continue
    counts['currentHealthPassed']+=1;ctx=D.context(L,S);carry=ctx['indicativeCarryDailyPctOfOneLeg']
    if ctx['currentRatio']is None or carry is None or carry<-.1:continue
    counts['carryPassed']+=1
    m.update(dailyTailP95Pct=max(quality[L]['dailyLegTailP95Pct'],quality[S]['dailyLegTailP95Pct']),dailyTailMaxPct=max(quality[L]['dailyLegTailMaxPct'],quality[S]['dailyLegTailMaxPct']),dailyContextLastClose=D.cut-1,chartDailyOverview=True,trendPatternRevision='daily-structural-v2',selectedDetailFrame=self.frame)
    out.append(self.row(L,S,m,100*m['dailyTrendR2Min'],stage='Daily rising structure; inspect current pullback',dailyPattern=True))
  return sorted(out,key=lambda r:(-r['metrics']['dailyTrendR2Min'],r['metrics']['dailyDrawdown360Pct'],r['metrics']['dailyTailP95Pct'],r['pair']))

 def trend_range(self):
  from trend_range import WINDOWS,prior_metrics,rank_score,daily_bars_valid,leg_tail_metrics
  D=self if self.frame=='daily'else Search(self.path,'daily');eligible=[];tails={};out=[]
  bad={'historyOrOHLCRejected':0,'practicalRejected':0}
  self.warnings.append('New KNC/AEVO-inspired descriptive screen: a separate prior360-calendar-day uptrend followed by90/180/270 DAILY closes of consolidation. Detail timeframe never changes these daily gates. This is not a proven trading edge or profit probability.')
  self.warnings.append('Bands are fitted10th/90th-percentile close levels, not guaranteed support or actual intrabar lows. Prior drawdown and individual-leg tails are shown, not hidden. Latest rates give indicative carry only; future funding and net returns remain unknown.')
  for r in D.rows:
   sym=r['symbol'];bars=r['bars']
   if not daily_bars_valid(bars,452):bad['historyOrOHLCRejected']+=1;continue
   leg=D.context(sym,sym)['legs'][0]
   if not positive(leg['mark'])or leg['volume30USDT']is None or leg['volume30USDT']<2e6 or leg['spreadPct']is None or leg['spreadPct']>.15:bad['practicalRejected']+=1;continue
   eligible.append(r);tails[sym]=leg_tail_metrics(bars)
  self.counts={'dailyCoverage':{'completeContracts':len(D.rows),'screenableContracts':len(eligible),**bad},'windows':{}}
  for n in WINDOWS:
   rs=[r for r in eligible if len(r['bars'])>=n+362];counts={'contracts':len(rs),'unorderedPairs':len(rs)*(len(rs)-1)//2,'prefilterPassed':0,'priorTrendPassed':0,'rangePassed':0,'markAndCarryPassed':0};self.counts['windows'][str(n)]=counts
   logs=np.log(np.array([[v[4]for v in r['bars'][-n-362:]]for r in rs]))if rs else np.empty((0,n+362))
   for i,A in enumerate(rs[:-1]):
    z=logs[i]-logs[i+1:];p=z[:,:361];direction=np.where(p[:,-1]>=p[:,0],1.,-1.);y=z*direction[:,None];p=y[:,:361];t=np.arange(361)-180;center=p-p.mean(axis=1,keepdims=True);cov=center@t;ss=(center*center).sum(axis=1)
    with np.errstate(divide='ignore',invalid='ignore'):r2=cov*cov/((t@t)*ss)
    x=y[:,-n-1:-1];lo,hi=np.quantile(x,[.1,.9],axis=1);w=hi-lo;safe=np.where(w>0,w,1.);rt=np.arange(n)-(n-1)/2;drift=abs((x-x.mean(axis=1,keepdims=True))@rt/(rt@rt)*(n-1))/safe;parts=np.array([np.quantile(x[:,k*n//3:(k+1)*n//3],[.1,.9],axis=1)for k in range(3)]);shift=np.maximum(np.ptp(parts[:,0,:],axis=0),np.ptp(parts[:,1,:],axis=0))/safe;widths=(parts[:,1,:]-parts[:,0,:])/safe
    good=(p[:,-1]-p[:,0]>=math.log1p(.25))&(cov>0)&(r2>=.45)&(w>=math.log(1.1))&(w<=math.log(1.6))&(drift<=.5)&(shift<=.45)&np.all((widths>=.45)&(widths<=1.8),axis=0)&(y[:,-1]>=np.max(y,axis=1)+math.log(.65));counts['prefilterPassed']+=int(sum(good))
    for j in np.flatnonzero(good):
     B=rs[i+1+int(j)];L,S=(A['symbol'],B['symbol'])if direction[j]>0 else(B['symbol'],A['symbol']);m,reasons=prior_metrics(y[j],n)
     if reasons:continue
     counts['priorTrendPassed']+=1;g=geometry(x[j],float(y[j,-1]),False)
     if not g or not g['pass']:continue
     counts['rangePassed']+=1;ctx=D.context(L,S);carry=ctx['indicativeCarryDailyPctOfOneLeg'];current=ctx['currentRatio']
     if current is None or carry is None or carry<-.1:continue
     loc=(math.log(current)-g['loLog'])/g['widthLog']
     pullback=100*(-math.expm1(math.log(current)-float(max(y[j]))))
     if not 0<=loc<=1 or pullback>35:continue
     counts['markAndCarryPassed']+=1;strict=geometry(x[j],float(y[j,-1]),True)
     previous=geometry(y[j,-2*n-1:-n-1],float(y[j,-n-1]),False)if len(y[j])>=2*n+1 else None
     recentLow=min(y[j,-n-1:-1]);score=rank_score(g,m['priorTrendR2'],loc)
     m.update(trendRangePass=True,contextPeakPullbackPct=pullback,formationBars=n,locationPct=100*loc,nearRangeBottom=bool(loc<=.4),bandLow=g['low'],bandHigh=g['high'],bandMid=math.exp((g['loLog']+g['hiLog'])/2),bandWidthPct=100*math.expm1(g['widthLog']),rangeQualityScore=g['score'],driftWidths=g['drift'],boundaryShiftWidths=g['shift'],transitions=g['transitions'],confirmedLows=g['lows'],confirmedHighs=g['highs'],extremaMADWidths=g['mad'],strictRangePass=bool(strict and strict['pass']),previousRangePass=bool(previous and previous['pass']),dailyTailP95Pct=max(tails[L]['p95'],tails[S]['p95']),dailyTailMaxPct=max(tails[L]['max'],tails[S]['max']),dailyContextLastClose=D.cut-1,rangeStart=D.cut-(n+1)*DAY,rangeEndExclusive=D.cut-DAY,trendStart=D.cut-(n+362)*DAY,trendEndExclusive=D.cut-(n+1)*DAY,chartDailyOverview=True,latestCompletedLocationPct=100*g['logPosition'],latestCloseVsFloorPct=100*math.expm1(float(y[j,-1])-g['loLog']),rangeMinimumClose=math.exp(recentLow),detailFrame=self.frame)
     out.append(self.row(L,S,m,score,geometry=g,stage='Lower range; turn unconfirmed'if loc<=.4 else'Watch for lower entry',dailyPattern=True))
  chosen={}
  key=lambda r:(not r['metrics']['nearRangeBottom'],-r['score'],-r['metrics']['formationBars'],r['pair'])
  for r in sorted(out,key=key):
   k=(r['long'],r['short'])
   if k not in chosen:chosen[k]=r;chosen[k]['metrics']['passingWindows']=[]
   chosen[k]['metrics']['passingWindows'].append(r['metrics']['formationBars'])
  return sorted(chosen.values(),key=key)

 def slow_grind(self):
  from slow_grind import leg_quality,recovery_metrics,BARS
  self.warnings.append('New DOGE/SHELL-inspired descriptive hypothesis. Smooth past closes do not establish future profit. Leg tails are screened individually; pair intrabar wicks/drawdown are unknown. No net funding/fee return is inferred.')
  eligible=[];leg_counts={'missingHistory':0,'wickOrJumpRejected':0,'liquidityOrQuoteRejected':0};out=[]
  for r in self.rows:
   s=r['symbol'];a=r['bars']
   if len(a)<90+BARS+1:leg_counts['missingHistory']+=1;continue
   quality,reasons=leg_quality(a,self.frame)
   if reasons:leg_counts['wickOrJumpRejected']+=1;continue
   ctx=self.context(s,s);leg=ctx['legs'][0]
   if not positive(leg['mark'])or leg['volume30USDT']is None or leg['volume30USDT']<2e6 or leg['spreadPct']is None or leg['spreadPct']>.15:
    leg_counts['liquidityOrQuoteRejected']+=1;continue
   eligible.append(r)
  self.counts={'coverage':{'completeContracts':len(self.rows),'screenableContracts':len(eligible),**leg_counts},'pipeline':{'unorderedPairs':len(eligible)*(len(eligible)-1)//2,'advancePassed':0,'smoothRecoveryPassed':0,'priorRangePassed':0,'headroomPassed':0,'carryPassed':0}}
  counts=self.counts['pipeline']
  logs={r['symbol']:np.log(np.array([v[4]for v in r['bars'][-BARS-1:]]))for r in eligible}
  for i,A in enumerate(eligible[:-1]):
   for B in eligible[i+1:]:
    aa,bb=A['symbol'],B['symbol'];gain=float((logs[aa][-1]-logs[aa][0])-(logs[bb][-1]-logs[bb][0]));L,S=(aa,bb)if gain>=0 else(bb,aa)
    if not math.log1p(.02)<=abs(gain)<=math.log1p(.20):continue
    counts['advancePassed']+=1;a,b=self.by[L]['bars'],self.by[S]['bars'];m,reasons=recovery_metrics(a,b,self.frame)
    if reasons:continue
    counts['smoothRecoveryPassed']+=1;x=self.series(L,S);start=float(x[-BARS-1]);gs=[]
    for n in [90,180]:
     if len(x)<n+BARS+1:continue
     g=geometry(x[-n-BARS-1:-BARS-1],start,False)
     if g and g['pass']:gs.append({'bars':n,**g})
    if not gs:continue
    counts['priorRangePassed']+=1;valid=[]
    for g in gs:
     startloc=(start-g['loLog'])/g['widthLog'];loc=(float(x[-1])-g['loLog'])/g['widthLog']
     if -.25<=startloc<=.65 and loc<=.85:valid.append((g,startloc,loc))
    if not valid:continue
    counts['headroomPassed']+=1;g,startloc,loc=max(valid,key=lambda v:(v[0]['bars'],v[0]['score']));ctx=self.context(L,S);carry=ctx['indicativeCarryDailyPctOfOneLeg']
    if ctx['currentRatio']is None or carry is None or carry<-.1:continue
    counts['carryPassed']+=1
    m.update(slowGrindPass=True,formationBars=g['bars'],formationDays=g['bars']*self.step/DAY,passingWindows=[v[0]['bars']for v in valid],rangeFitEndsBeforeRecovery=True,startLocationPct=startloc*100,locationPct=loc*100,headroomPctOfBand=(1-loc)*100,priorRangeTransitions=g['transitions'],priorRangeDriftWidths=g['drift'])
    out.append(self.row(L,S,m,100*m['directionalEfficiency'],geometry=g,stage='Observed slow recovery; inspect entry timing'))
  return sorted(out,key=lambda r:(-r['metrics']['directionalEfficiency'],r['metrics']['equalNotionalDrawdownPct'],-r['metrics']['equalNotionalRetainedPct'],r['pair']))

 def run(self,definition):
  e=definition['engine']
  if e=='recovery35':
   from recovery35 import search
   return search(self)
  if e=='daily_confirmed_range':
   from daily_confirmed_range import search
   return search(self)
  if e=='ticker_extremes':
   from ticker_extremes import search
   return search(self)
  if e=='alt_strk':
   from alt_strk import search
   return search(self)
  if e=='first20':
   from first20 import search
   return search(self)
  if e=='opposing_bias':
   from opposing_bias import search
   return search(self)
  if e=='clear_daily':
   if definition.get('revision')=='2026-10-20-clear-daily-v2':
    from clear_daily_v2 import search
   else:
    from clear_daily import search
   return search(self)
  if e=='clean_drive':
   from clean_drive import search
   return search(self)
  if e=='consistent_channels':
   from consistent_channels import search
   return search(self)
  if e=='clean_bases':
   from clean_bases import search
   return search(self)
  if e=='consistent':return self.consistent()
  if e=='slow_grind':return self.slow_grind()
  if e=='daily_trend':return self.daily_trend()
  if e=='trend_range':return self.trend_range()
  if e in ['range','edge','ultra','new']:return self.range_rows(definition)
  if e in ['osc','missing','regime']:
   v=self.oscillators(definition.get('scope','broad'),definition.get('persistent',False));self.counts=v['counts'];out=[]
   for p in v['rows']:
    g=p['geometry'];d=1 if g['currentZ']<=0 else -1;L,S=(p['a'],p['b'])if d==1 else(p['b'],p['a']);out.append(self.row(L,S,{'priorWindowPass':p['previousPass'],**g},g['transitions'],stage='Oscillator shape, not entry'))
   return out
  if e=='reversal':return self.reversal(definition.get('confirmed',False))
  if e=='extreme':return self.extreme()
  if e=='pump':return self.pump(definition)
  if e=='moderate':return self.moderate()
  if e=='fingerprint':return self.fingerprints(definition)
  if e=='confluence':return self.confluence()
  if e in ['core','channel']:return self.core(definition)
  raise ValueError('Unknown search engine '+e)
 def core(self,definition):
  kind='channel'if definition['engine']=='channel'else'core';file=self.path/('computed-'+self.frame+'-'+kind+'.json')
  if not file.exists():
   out=subprocess.run(['/opt/homebrew/bin/node',str(ROOT/'core.cjs'),str(self.path),self.frame,kind,str(file)],cwd=ROOT,capture_output=True,text=True)
   if out.returncode:raise RuntimeError(out.stderr[-1200:])
  data=read(file);self.counts=data['counts'];self.warnings+=data.get('warnings',[]);rows=data['channel']if kind=='channel'else data['raw'];out=[];mode=definition.get('channelMode');variant=definition.get('variant','original')
  for s in rows:
   if kind=='channel':
    if mode=='stoch'and not(s.get('stochTurn')and s.get('chartSide')==definition.get('side')):continue
    if mode=='control'and not s.get('rangeControl'):continue
    if mode=='sequence_simple'and not s.get('sequenceModes',{}).get('simple'):continue
    if mode=='sequence_cross'and not s.get('sequenceModes',{}).get('cross'):continue
   else:
    if variant=='legacy_fall_volume':
     if not(finite(s.get('fall'))and s['fall']>=.5 and finite(s.get('volumeLogRatio'))and s['volumeLogRatio']>=0):continue
    elif variant!='legacy_first'and not s.get('strict'):continue
    if variant=='BOUNCE1'and not(s.get('features',{}).get('bounceZ')is not None and s['features']['bounceZ']>=1):continue
    gate=definition.get('gate',{}).get('all',[])
    def test(c):
     v=s.get('features',{}).get(c['feature']);w=s.get('features',{}).get(c['otherFeature'])if 'otherFeature'in c else c['value'];return finite(v)and finite(w)and {'gte':lambda:v>=w,'gt':lambda:v>w,'lte':lambda:v<=w,'lt':lambda:v<w,'eq':lambda:v==w}[c['op']]()
    if not all(test(c)for c in gate):continue
   out.append(self.row(s['long'],s['short'],{'zEntry':s.get('entryZ'),'fallLog':s.get('fall'),'volumeLogRatio':s.get('volumeLogRatio'),'features':s.get('features',{}),'carry7d':None,'fundingEligibility':'UNKNOWN — full7-day carry not verified'},s.get('gap',0),stage='Price candidate; funding not yet eligible',signalTime=s['signalTime'],raw=s))
  return out

def execute(snapshot,definition,frame,settings):
 e=definition['engine'];S=Search(snapshot,'daily'if e in ['trend_range','first20','opposing_bias']else frame);S.frame=frame;held=set(settings.get('heldTokens',[]))if settings.get('excludeHeld',True)else set();messages=[]
 if frame!='daily'and e not in ['slow_grind','daily_trend','trend_range','first20','opposing_bias']:S.warnings.append('Selected timeframe changes bar-based formation windows; daily-only research becomes a new, unvalidated timeframe adaptation. Fourteen-bar moves are not fourteen-day moves outside daily.')
 if e=='weekend':
  rows=[];S.counts={'importedOpenPairs':len(settings.get('pairs',[]))}
  for p in settings.get('pairs',[]):
   L,H=p['long'],p['short']
   if L not in S.by or H not in S.by:continue
   x=S.series(L,H);n=min(len(S.by[L]['bars']),len(S.by[H]['bars']));bs=S.by[L]['bars'][-n:];ret=np.diff(x);week=np.array([datetime.datetime.fromtimestamp(b[6]/1000,datetime.timezone.utc).weekday()>=5 for b in bs[1:]])
   groups=[ret[week],ret[~week]]
   if min(len(g)for g in groups)<12:continue
   a,b=groups;rows.append(S.row(L,H,{'weekendObservations':len(a),'weekdayObservations':len(b),'weekendSDPct':a.std(ddof=1)*100,'weekdaySDPct':b.std(ddof=1)*100,'weekendVsWeekdaySD':a.std(ddof=1)/b.std(ddof=1)if b.std(ddof=1)>0 else None,'weekendMeanAbsPct':np.mean(abs(a))*100,'weekdayMeanAbsPct':np.mean(abs(b))*100,'weekendP90AbsPct':np.quantile(abs(a),.9)*100,'weekdayP90AbsPct':np.quantile(abs(b),.9)*100},stage='UTC per-bar comparison'))
 else:rows=S.run(definition)
 if e=='alt_strk'and settings.get('altStrkPriorRecovery',False):
  from alt_strk_history import filter_rows
  rows=filter_rows(S,rows)
  definition={**definition,'title':definition['title']+' · prior dip & recovery','conditions':definition['conditions']+['Optional prior recovery filter ON: long RSI(14)<=30 OR short RSI(14)>=70 during current14-close dip through its trough. Within365 prior days, a comparable closing low (factor1.25) fell>=20% from its prior60-day peak, then rose>=25% AND recovered half that decline within90 daily closes, all before current setup base. Independent completed episodes only; historical landmarks are not a guaranteed range or target.'],'sources':definition['sources']+['research/alt_strk_prior_recovery_2026-10-21/contract.json','setup-search/alt_strk_history.py']}
 # Apply occupied-token exclusions AFTER the original universe/signal computation.
 if e in ['range','edge','ultra','new','moderate','reversal','consistent']:
  for window,coverage in S.counts.items():
   if isinstance(coverage,dict)and coverage.get('contracts',0)<2:S.warnings.append(str(window)+'-bar formation was not screened: insufficient complete contract histories.')
 if e=='ultra':
  for n in definition.get('days',[180,360]):
   count=sum(len(r['bars'])>=2*n+1 for r in S.rows);S.counts.setdefault(str(n),{})['contractsWithBothWindows']=count
   if count<2:S.warnings.append(str(n)+'-bar repeated-window test is unavailable: requires '+str(2*n+1)+' consecutive selected-frame bars per leg.')
 before=len(rows)
 if e=='ticker_extremes':
  for r in rows:r['metrics']['heldCoin']=r['ticker']in set(settings.get('heldTokens',[]))
  held=set();messages.append('All covered tickers, including held coins. Daily RSI(14) >=70 is overbought; <=30 is oversold. Completed candles only; no reversal or trade-entry confirmation required.')
 if e not in ['weekend','confluence','ticker_extremes']:rows=[r for r in rows if r['long']not in held and r['short']not in held]
 if e=='missing':
  known={tuple(sorted(x))for x in settings.get('watchlist',[])}
  if not settings.get('watchlistImported'):rows=[];messages.append('Import a TradingView watchlist to compare. No missing-list result inferred without it.')
  else:rows=[r for r in rows if tuple(sorted([r['long'],r['short']]))not in known]
 if (e=='range'and definition.get('strict',True))or e=='new':
  # Compare complete same-timeframe shape libraries, never a single-window shortlist or occupied-token subset.
  libdir=ROOT/'storage/range-libraries';libdir.mkdir(exist_ok=True);file=libdir/(Path(snapshot).name+'-'+frame+'.json');full=S.ranges(True,[90,180,360,720]);pairs=sorted({tuple(sorted([p['a'],p['b']]))for p in full['rows']})
  older=[]
  for f in libdir.glob('*.json'):
   if f.name.startswith('._'):continue
   v=read(f)
   if v['frame']==frame and v['cutoff']<S.cut:older.append(v)
  if not file.exists():write(file,{'snapshot':str(Path(snapshot).resolve()),'frame':frame,'cutoff':S.cut,'quoteAsOf':S.meta['serverTime'],'createdAt':utc(),'pairs':pairs})
  if e=='new':
   if not older:rows=[];messages.append('Current complete shape library saved. A preceding stored candle-period library is not yet available; no newly formed pairs inferred.')
   else:
    old=max(older,key=lambda v:v['cutoff']);keys={tuple(p)for p in old['pairs']};rows=[r for r in rows if tuple(sorted([r['long'],r['short']]))not in keys];messages.append('Compared with preceding stored candle-period library ending '+datetime.datetime.fromtimestamp((old['cutoff']-1)/1000,datetime.timezone.utc).isoformat())
 if e in ['first20','opposing_bias']:S.cut=S.meta['cutoffs'][frame]
 for r in rows:
  r['context']=S.context(r['long'],r['short']);r['timeframe']=frame;r['numericalOnly']=True
  if e=='ticker_extremes':r['tradingView']='BINANCE:'+r['ticker']+'.P'
  if r['long']!=r['short']:r['tradingView']='BINANCE:'+r['long']+'.P/BINANCE:'+r['short']+'.P'
 if e=='regime':
  btc=S.dmap.get('BTCUSDT',{}).get('bars',[]);alt=[r['bars'][-1][4]/r['bars'][-31][4]-1 for s,r in S.dmap.items()if s!='BTCUSDT'and len(r['bars'])>=31]
  if len(btc)>=31:messages.append('Daily market context: BTC30d '+str(round(100*(btc[-1][4]/btc[-31][4]-1),2))+'%; BTC5d '+str(round(100*(btc[-1][4]/btc[-6][4]-1),2))+'%; median current-alt30d '+str(round(100*float(np.median(alt)),2))+'%. Current-universe descriptive comparison.')
 return clean({**({'cleanDriveEvidence':S.clean_drive_evidence,'cleanDriveCounts':{'clean':sum(r['metrics']['driveCleanPass'] for r in rows),'nearMatches':sum(not r['metrics']['driveCleanPass'] for r in rows)}}if e=='clean_drive'else{}),**({'options':{'altStrkPriorRecovery':True},'priorRecoveryEvidence':S.prior_recovery_evidence}if e=='alt_strk'and settings.get('altStrkPriorRecovery',False)else{}),**({'biasEvidence':S.bias_evidence}if e=='opposing_bias'else{}),**({'dailyContextLastClose':S.meta['cutoffs']['daily']-1}if e in ['daily_trend','trend_range','first20','opposing_bias']else{}),'searchId':definition['id'],'title':definition['title'] if frame=='daily' else definition['title'].replace('-day','-bar')+' · '+{'four':'4h','hourly':'1h'}[frame],'frame':frame,'createdAt':utc(),'sourceSnapshot':str(Path(snapshot).resolve()),'quoteAsOf':S.meta['serverTime'],'lastCompletedBar':S.cut-1,'counts':S.counts,'matchesBeforeHeldExclusion':before,'heldTokensExcluded':len(held),'matches':len(rows),'rows':rows,'messages':messages,'warnings':S.warnings,'method':'Descriptive current-universe numerical matches. No orders, strategy promotion or profit probabilities.','definition':definition})
if __name__=='__main__':
 snap,model,frame,out,setting=sys.argv[1:];catalog=read(ROOT/'catalog.json');definition=next(r for r in catalog['rows']if r['id']==model);write(out,execute(snap,definition,frame,read(setting)))
