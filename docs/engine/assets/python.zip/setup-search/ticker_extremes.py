"""Individual daily RSI stretch overview, separate from paired entry rules."""
import math

def rsi14(closes):
 if len(closes)<15 or any(not math.isfinite(x) or x<=0 for x in closes):return None
 changes=[b-a for a,b in zip(closes,closes[1:])]
 gain=sum(max(x,0) for x in changes[:14])/14
 loss=sum(max(-x,0) for x in changes[:14])/14
 for x in changes[14:]:
  gain=(13*gain+max(x,0))/14
  loss=(13*loss+max(-x,0))/14
 return 100*gain/(gain+loss) if gain+loss>0 else None

def classify(value):
 if value is None or not math.isfinite(value):return None
 return 'Overbought' if value>=70 else 'Oversold' if value<=30 else None

def search(S):
 if S.frame!='daily':raise ValueError('Extreme tickers uses completed DAILY closes only.')
 counts={'contractsScreened':len(S.rows),'rsiAvailable':0,'insufficientHistory':0,'undefinedRSI':0,'overbought':0,'oversold':0,'notExtreme':0}
 out=[]
 for row in S.rows:
  bars=row['bars'];closes=[b[4] for b in bars]
  if len(closes)<15:counts['insufficientHistory']+=1;continue
  value=rsi14(closes)
  if value is None:counts['undefinedRSI']+=1;continue
  counts['rsiAvailable']+=1;side=classify(value)
  if side is None:counts['notExtreme']+=1;continue
  counts[side.lower()]+=1;symbol=row['symbol']
  metrics={'tickerExtreme':True,'extremeSide':side,'rsi14':value,'extremity':abs(value-50),'dailyClose':closes[-1],'dailyChangePct':100*(closes[-1]/closes[-2]-1),'historyBars':len(closes),'indicatorCloseTime':bars[-1][6]}
  out.append(S.row(symbol,symbol,metrics,abs(value-50),ticker=symbol,pair=symbol,stage=side+' · daily RSI(14), no reversal confirmation'))
 S.counts=counts
 return sorted(out,key=lambda r:(-r['metrics']['extremity'],r['ticker']))
