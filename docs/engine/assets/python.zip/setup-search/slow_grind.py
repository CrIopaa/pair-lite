"""Exploratory, close-based slow recovery screen; independent leg-wick filters.
No synthetic ratio OHLC, forward return, funding cash or execution assumption.
"""
import math
import numpy as np

FRAME_LIMITS = {
 'daily': {'maxWickPct': 12., 'maxCloseJumpPct': 15.},
 'four': {'maxWickPct': 6., 'maxCloseJumpPct': 8.},
 'hourly': {'maxWickPct': 3., 'maxCloseJumpPct': 4.},
}
BARS = 24

def leg_quality(bars, frame):
 """Require 25 synchronous valid bars, inspect the last 24 complete candles."""
 a=np.asarray(bars,float)
 if len(a)<BARS+1 or a.ndim!=2 or a.shape[1]<7:
  return None,['Incomplete recovery candles']
 a=a[-BARS-1:]
 if not np.isfinite(a).all()or np.any(a[:,1:5]<=0)or np.any(a[:,5]<0):
  return None,['Invalid leg candles']
 if np.any(a[:,2]<np.max(a[:,[1,3,4]],axis=1))or np.any(a[:,3]>np.min(a[:,[1,2,4]],axis=1)):
  return None,['Invalid leg OHLC']
 step={'daily':86400000,'four':14400000,'hourly':3600000}[frame]
 if not np.all(np.diff(a[:,0])==step)or not np.all(a[:,6]-a[:,0]==step-1)or not np.all(a[:,0]%step==0):
  return None,['Gapped recovery candles']
 v=a[1:];upper=np.log(v[:,2]/np.maximum(v[:,1],v[:,4]));lower=np.log(np.minimum(v[:,1],v[:,4])/v[:,3]);tails=np.maximum(upper,lower);ranges=np.log(v[:,2]/v[:,3]);tail=float(max(tails));typical=float(np.median(ranges));jumps=np.abs(np.diff(np.log(a[:,4])));cap=FRAME_LIMITS[frame];reasons=[]
 if tail>math.log1p(cap['maxWickPct']/100)+1e-12:reasons.append('Large leg wick')
 if tail>max(math.log1p(.01),4*typical)+1e-12:reasons.append('Isolated leg wick')
 if max(jumps)>math.log1p(cap['maxCloseJumpPct']/100)+1e-12:reasons.append('Large leg close jump')
 return {'maxWickPct':100*math.expm1(tail),'medianRangePct':100*math.expm1(typical),'maxCloseJumpLogPct':100*float(max(jumps))},reasons

def recovery_metrics(a,b,frame):
 """All metrics are observed BEFORE screening; fixed equal-start-notional path."""
 qa,ra=leg_quality(a,frame);qb,rb=leg_quality(b,frame)
 if qa is None or qb is None:return None,sorted(set(ra+rb))
 a=np.asarray(a[-BARS-1:],float);b=np.asarray(b[-BARS-1:],float)
 if not np.array_equal(a[:,0],b[:,0])or not np.array_equal(a[:,6],b[:,6]):return None,['Unsynchronised recovery candles']
 y=np.log(a[:,4]/b[:,4]);y=y-y[0];delta=np.diff(y);net=float(y[-1]);variation=float(sum(abs(delta)));up=int(sum(delta>0));blocks=np.diff(y[::4]);t=np.arange(BARS+1);slope=float(np.polyfit(t,y,1)[0]);ss=float(sum((y-y.mean())**2));r2=float(np.corrcoef(t,y)[0,1]**2)if ss>0 else 0.;peak=float(max(y));dd=float(max(np.maximum.accumulate(y)-y));eff=net/variation if variation>0 else 0.;retained=net/peak if peak>0 else None;biggest=float(max(abs(delta))/variation)if variation>0 else 1.
 p=(a[:,4]/a[0,4]-b[:,4]/b[0,4])/2;pn=float(p[-1]);pp=float(max(p));pd=float(max(np.maximum.accumulate(p)-p));pr=pn/pp if pp>0 else None;reasons=sorted(set(ra+rb))
 tests=[(math.log1p(.02)-1e-12<=net<=math.log1p(.20)+1e-12,'Ratio advance outside 2–20%'),(up/BARS>=.58,'Too few rising closes'),(sum(blocks>0)>=4,'Too few rising four-bar blocks'),(eff>=.3,'Low directional efficiency'),(slope>0 and r2>=.5,'Irregular recovery trend'),(net>0 and dd<=.4*net+1e-12,'Large close giveback'),(retained is not None and retained>=.75,'Late peak giveback'),(biggest<=.3,'Single jump dominates'),(y[-1]>y[-9],'Last eight bars not rising'),(pn>=.005,'Equal-notional gain below 0.5%'),(pr is not None and pr>=.7,'Equal-notional peak giveback'),(pn>0 and pd<=.6*pn+1e-12,'Equal-notional drawdown too large')]
 reasons += [name for passed,name in tests if not passed]
 m={'recoveryBars':BARS,'recoveryDays':BARS*(a[0,6]-a[0,0]+1)/86400000,'ratioAdvancePct':100*math.expm1(net),'positiveClosesPct':100*up/BARS,'positiveFourBarBlocks':int(sum(blocks>0)),'directionalEfficiency':eff,'recoveryTrendR2':r2,'ratioCloseDrawdownPct':100*math.expm1(dd),'drawdownVsAdvancePct':100*dd/net if net>0 else None,'peakRetainedPct':100*retained if retained is not None else None,'largestStepPathSharePct':100*biggest,'equalNotionalGainPct':100*pn,'equalNotionalDrawdownPct':100*pd,'equalNotionalRetainedPct':100*pr if pr is not None else None,'maxLegWickPct':max(qa['maxWickPct'],qb['maxWickPct']),'longMaxWickPct':qa['maxWickPct'],'shortMaxWickPct':qb['maxWickPct'],'longRecoveryPct':100*(a[-1,4]/a[0,4]-1),'shortPriceRecoveryPct':100*(b[-1,4]/b[0,4]-1),'recoveryStart':int(a[0,6]),'recoveryEnd':int(a[-1,6])}
 return m,reasons
