"""Click-driven public snapshots. All persistent state stays beside this file."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import datetime,hashlib,importlib.util,json,sys,time
ROOT=Path(__file__).resolve().parent; PROJECT=ROOT.parent
DAY=86400000;FOUR=14400000;HOUR=3600000
EXCLUDED={'USDC','FDUSD','USDE','USDP','TUSD','DAI','PAXG','XAUT','BTCDOM','DEFI','FOOTBALL','BLUEBIRD'}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.pending');tmp.write_text(json.dumps(v,separators=(',',':'),allow_nan=False));tmp.replace(p)
def read(p):return json.loads(Path(p).read_text())
def progress(out,stage,done=0,total=0):write(out/'progress.json',{'stage':stage,'done':done,'total':total,'at':utc()});print(stage,done,total,flush=True)
def acquire(out,base=None,mode='daily'):
 out=Path(out);(out/'raw').mkdir(parents=True,exist_ok=True)
 spec=importlib.util.spec_from_file_location('public_snapshot',PROJECT/'research/oscillator_gallery_2026-10-13/fetch_gallery_data.py');G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G);G.ROOT=out;G.RAW=out/'raw'
 Q={'data':{},'sources':{}}
 for k,p in [('clock','time'),('info','exchangeInfo'),('marks','premiumIndex'),('book','ticker/bookTicker'),('funding','fundingInfo')]:
  v,s=G.get('/fapi/v1/'+p);Q['data'][k]=v;Q['sources'][k]=G.source(s)
 # Last trade prices determine unfinished chart candle colour; marks remain P&L context.
 try:
  v,s=G.get('/fapi/v2/ticker/price');Q['data']['trades']=v;Q['sources']['trades']=G.source(s)
 except Exception as e:Q['data']['trades']=[];Q['tradeQuoteError']=str(e)
 now=Q['data']['clock']['serverTime'];cuts={'daily':now//DAY*DAY,'four':now//FOUR*FOUR,'hourly':now//HOUR*HOUR};write(out/'public.json',Q)
 eligible=[i for i in Q['data']['info']['symbols']if i.get('status')=='TRADING' and i.get('contractType')=='PERPETUAL'and i.get('underlyingType')=='COIN'and i.get('quoteAsset')=='USDT'and i.get('marginAsset')=='USDT'and i['symbol'][:-4]not in EXCLUDED]
 cache=read(base)if base else{};old={r['symbol']:r for r in cache.get('rows',[])};reuse=cache.get('cutoffExclusive')==cuts['daily'];daily=[];errors=[]
 jobs=[]
 for i in eligible:
  s=i['symbol']
  if reuse and s in old:daily.append(old[s]);continue
  jobs.append((s,'daily','1d',721,cuts['daily'],DAY))
 if mode in ['all','four']:
  for i in eligible:jobs.append((i['symbol'],'four','4h',721,cuts['four'],FOUR))
 if mode in ['all','hourly']:
  for i in eligible:jobs.append((i['symbol'],'hourly','1h',721,cuts['hourly'],HOUR))
 datasets={'daily':daily,'four':[],'hourly':[]};sources={};progress(out,'Fetching completed public candles',0,len(jobs))
 def fetch(j):
  s,k,interval,n,cut,step=j
  try:
   v,src=G.get('/fapi/v1/klines',{'symbol':s,'interval':interval,'limit':n,'endTime':cut-1});bars=[]
   for b in v:
    t=int(b[0]);o,h,l,c=map(float,b[1:5]);qv=float(b[7]);ct=int(b[6]);assert t%step==0 and ct==t+step-1 and min(o,h,l,c)>0 and h>=max(o,c,l) and l<=min(o,c) and qv>=0
    bars.append([t,o,h,l,c,qv,ct])
   assert bars and bars[-1][0]==cut-step and all(bars[j][0]+step==bars[j+1][0]for j in range(len(bars)-1))
   return k,{'symbol':s,'complete':True,'bars':bars,'issues':[]},G.source(src),None
  except Exception as e:return k,{'symbol':s,'complete':False,'bars':[],'issues':[str(e)]},None,{'symbol':s,'kind':k,'error':str(e)}
 with ThreadPoolExecutor(max_workers=4)as pool:
  for n,f in enumerate(as_completed([pool.submit(fetch,j)for j in jobs]),1):
   k,r,src,err=f.result();datasets[k].append(r);sources[k+':'+r['symbol']]=src
   if err:errors.append(err)
   if n%20==0:progress(out,'Fetching completed public candles',n,len(jobs))
 for k,rows in datasets.items():
  if not rows:continue
  write(out/(k+'.json'),{'createdAt':utc(),'cutoffExclusive':cuts[k],'step':{'daily':DAY,'four':FOUR,'hourly':HOUR}[k],'rows':sorted(rows,key=lambda r:r['symbol']),'reuse':str(base)if k=='daily'and reuse else None,'sources':sources})
 for k in ['four','hourly']:
  if not datasets[k] and base and (Path(base).parent/(k+'.json')).exists():
   source=Path(base).parent/(k+'.json');oldframe=read(source)
   if oldframe['cutoffExclusive']==cuts[k]:
    oldframe={**oldframe,'reusedFrom':str(source.resolve()),'reusedSha256':hashlib.sha256(source.read_bytes()).hexdigest()};write(out/(k+'.json'),oldframe);datasets[k]=oldframe['rows']
 # Current UTC opens are a separate dataset, never incomplete historical candles.
 prior=Path(base).parent/'current_day_opens.json' if base else None
 previous=read(prior) if prior and prior.exists() else {}
 cached=previous.get('opens',{}) if previous.get('dayStart')==cuts['daily'] else {}
 opens={s:v for s,v in cached.items() if s in {i['symbol'] for i in eligible}}
 missing=[i['symbol'] for i in eligible if i['symbol'] not in opens]
 def fetch_open(s):
  try:
   v,src=G.get('/fapi/v1/klines',{'symbol':s,'interval':'1d','startTime':cuts['daily'],'endTime':now,'limit':1})
   assert len(v)==1 and int(v[0][0])==cuts['daily'] and int(v[0][6])==cuts['daily']+DAY-1
   o=float(v[0][1]);assert o>0 and o<float('inf')
   return s,{'open':o,'openTime':cuts['daily'],'closeTime':cuts['daily']+DAY-1,'source':G.source(src)},None
  except Exception as e:return s,None,{'symbol':s,'kind':'currentDayOpen','error':str(e)}
 progress(out,'Fetching current UTC daily opens',0,len(missing))
 with ThreadPoolExecutor(max_workers=4) as pool:
  for n,f in enumerate(as_completed([pool.submit(fetch_open,s) for s in missing]),1):
   s,v,err=f.result()
   if v:opens[s]=v
   if err:errors.append(err)
   if n%20==0:progress(out,'Fetching current UTC daily opens',n,len(missing))
 write(out/'current_day_opens.json',{'dayStart':cuts['daily'],'quoteAsOf':now,'opens':opens,'reusedFrom':str(prior.resolve()) if cached else None,'reusedSha256':hashlib.sha256(prior.read_bytes()).hexdigest() if cached else None,'meaning':'Only opening price of unfinished UTC day; no incomplete candle used as completed history.'})
 summary={'createdAt':utc(),'serverTime':now,'cutoffs':cuts,'contracts':len(eligible),'mode':mode,'errors':errors,'currentDailyOpens':len(opens),'reuseDaily':reuse,'dailySource':str(base)if reuse else None,'dailySourceSha256':hashlib.sha256(Path(base).read_bytes()).hexdigest()if reuse else None,'counts':{k:len(v)for k,v in datasets.items()}}
 write(out/'snapshot.json',summary);progress(out,'Snapshot ready',len(jobs),len(jobs));return summary
if __name__=='__main__':
 out=Path(sys.argv[1]);base=Path(sys.argv[2])if len(sys.argv)>2 and sys.argv[2]!='-'else None;mode=sys.argv[3]if len(sys.argv)>3 else'daily';acquire(out,base,mode)
