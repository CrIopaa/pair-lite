"""Reusable numerical stage of the screenshot-guided clean bases study.

The prior visual vetoes and discretionary closest-50 list are not filters here.
Contract: research/clean_bases_button_2026-10-20/contract.json.
"""
import math
from collections import Counter, defaultdict
import numpy as np
from clear_daily_v2 import recent_chop
from trend_range import daily_bars_valid

WINDOWS = (90, 180, 360)


def clarity(values, geometry):
    y = np.asarray(values, float)
    if len(y) < 91 or not np.isfinite(y).all():
        return None, ['Missing completed daily closes']
    x = y[:-1]; g = geometry; width = g['widthLog']; lo = g['loLog']
    if not width > 0:
        return None, ['Invalid fitted width']
    efficiencies = []; start = side = None
    for i, v in enumerate(x):
        edge = -1 if v <= lo+.2*width else 1 if v >= lo+.8*width else 0
        if edge and side is None:
            side, start = edge, i
        elif edge and edge != side:
            path = float(np.abs(np.diff(x[start:i+1])).sum())
            efficiencies.append(abs(float(x[i]-x[start]))/path if path else 0.)
            side, start = edge, i
    if len(efficiencies) < 5:
        return None, ['Fewer than five opposite crossings']
    median = float(np.median(efficiencies)); q25 = float(np.quantile(efficiencies, .25))
    chop, reasons = recent_chop(y, width)
    reasons += [name for ok, name in [
        (g['drift'] <= .35, 'Drift'), (g['shift'] <= .35, 'Boundary shift'),
        (g['mad'] <= .15, 'Unstable repeated extrema'),
        (median >= .25, 'Choppy median swing'), (q25 >= .15, 'Choppy lower swings')]
        if not ok]
    return dict(swingEfficiencyMedian=median, swingEfficiencyQ25=q25,
                completedSwingCount=len(efficiencies), **(chop or {})), reasons


def order(row):
    m = row['metrics']
    return (not m['longDailyContext'], not m['strictRangePass'],
            -m['matchingWindows'], m['boundaryIrregularity'],
            -m['swingEfficiencyMedian'], -m['formationBars'], row['pair'])


def search(owner):
    if owner.frame != 'daily':
        raise ValueError('Clean bases & highs uses daily candles only')
    from engine import geometry
    base = owner.ranges(False, WINDOWS); groups = defaultdict(list); rejected = Counter()
    for g in base['rows']:
        a, b, n = g['a'], g['b'], g['bars']
        if not all(daily_bars_valid(owner.by[s]['bars'], n+1) for s in [a, b]):
            rejected['Missing or malformed daily OHLCV'] += 1; continue
        y = owner.series(a, b)[-n-1:]; quality, reasons = clarity(y, g)
        if reasons:
            rejected.update(reasons); continue
        strict = geometry(y[:-1], y[-1], True)['pass']
        groups[(a, b)].append((g, quality, strict))
    rows = []
    for (a, b), matches in groups.items():
        g, quality, strict = max(matches, key=lambda v: (v[0]['bars'], v[2], -v[0]['shift']))
        ctx = owner.context(a, b); mark = ctx['currentRatio']
        pos = (math.log(mark)-g['loLog'])/g['widthLog'] if mark else None
        m = dict(cleanBases=True, formationBars=g['bars'], daysCovered=g['bars'],
                 longDailyContext=g['bars'] >= 180, strictRangePass=bool(strict),
                 passingWindows=sorted(v[0]['bars'] for v in matches), matchingWindows=len(matches),
                 bandLow=g['low'], bandHigh=g['high'], bandWidthPct=100*math.expm1(g['widthLog']),
                 driftWidths=g['drift'], boundaryShiftWidths=g['shift'],
                 extremaMADWidths=g['mad'], boundaryIrregularity=g['shift']+g['mad'],
                 transitions=g['transitions'], confirmedLows=g['lows'], confirmedHighs=g['highs'],
                 completedCloseLocationPct=g['logPosition']*100,
                 locationPct=pos*100 if pos is not None else None,
                 markOutside=None if pos is None else not 0 <= pos <= 1,
                 visualReviewRequired=True, **quality)
        rows.append(owner.row(a, b, m, g['score'], geometry=g,
                    stage='Repeated daily base/high zones · visual review required; no entry signal'))
    owner.counts = {**base['counts'], 'pipeline': dict(broadRangeWindows=len(base['rows']),
        clarityPassingWindows=sum(len(v) for v in groups.values()),
        uniquePairsBeforeHeldExclusion=len(rows)), 'clarityRejections': dict(rejected)}
    owner.warnings += [
        'Same numerical screen as the20October clean-bases TradingView study. Its42 manual chart vetoes and discretionary closest50 were visual judgments, not reusable automatic filters.',
        'Repeated DAILY low/high zones over90/180/360days. Earlier trends outside the formation do not veto a match.90day-only ranges are labelled shorter context.',
        'Canonical numerator/denominator are chart orientation only. No current edge, bounce, mark, funding or liquidity eligibility gate. Latest completed close must meet the inherited broad-band tolerance; missing mark stays unknown.',
        'Inspect each chart. Fitted quantile boundaries are retrospective estimates, not guaranteed support, persistent ranges or validated profit forecasts.']
    return sorted(rows, key=order)
