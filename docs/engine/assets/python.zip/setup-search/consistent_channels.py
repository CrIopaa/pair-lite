"""Current descriptive log-linear parallel channels, without entry timing.

Contract frozen in research/consistent_channels_2026-10-20/contract.json.
OLS uses the formation only. Its retrospectively fitted lines are not signals
that were available at earlier points inside that same formation.
"""
import math
from collections import Counter, defaultdict
import numpy as np
from trend_range import daily_bars_valid

DAY = 86400000
WINDOWS = (90, 180, 360, 720)


def channel_fit(values):
    x = np.asarray(values, float); n = len(x)
    if n < 90 or not np.isfinite(x).all():
        return None, ['Insufficient valid daily formation']
    t = np.arange(n)-(n-1)/2; mean = float(x.mean())
    slope = float(t@(x-mean)/(t@t)); residual = x-mean-slope*t
    lo, hi = np.quantile(residual, [.1, .9]); width = float(hi-lo)
    if width < math.log(1.1):
        return None, ['Channel narrower than10%']
    thirds = np.array([np.quantile(v, [.1, .9]) for v in np.array_split(residual, 3)])
    shift = float(max(np.ptp(thirds[:, 0]), np.ptp(thirds[:, 1]))/width)
    widths = (thirds[:, 1]-thirds[:, 0])/width
    drift = []
    for v in np.array_split(residual, 3):
        q = np.arange(len(v))-(len(v)-1)/2
        drift.append(abs(float(q@(v-v.mean())/(q@q)*(len(v)-1)))/width)
    reasons = []
    if shift > .25: reasons.append('Channel boundaries shift')
    if not np.all((widths >= .65) & (widths <= 1.5)): reasons.append('Channel width changes')
    if max(drift) > .50: reasons.append('Channel bends or changes slope')
    if reasons:
        return None, reasons
    states = []
    for i, v in enumerate(residual):
        side = -1 if v <= lo+.2*width else 1 if v >= lo+.8*width else 0
        if side and (not states or side != states[-1][1]):
            states.append((i, side))
    lows, highs = [], []
    for k in range(1, len(states)-1):
        i, side = states[k]; segment = residual[i:states[k+1][0]]
        (lows if side < 0 else highs).append(float(min(segment) if side < 0 else max(segment)))
    if len(states)-1 < 8 or min(len(lows), len(highs)) < 3:
        return None, ['Too few repeated channel swings']
    mad = max(float(np.median(abs(np.array(v)-np.median(v)))/width) for v in [lows, highs])
    durations = np.diff([i for i, _ in states]); median_duration = float(np.median(durations))
    duration_mad = float(np.median(abs(durations-median_duration))/median_duration)
    efficiencies = []
    for (a, _), (b, _) in zip(states, states[1:]):
        path = float(np.abs(np.diff(residual[a:b+1])).sum())
        efficiencies.append(abs(float(residual[b]-residual[a]))/path if path > 0 else 0.)
    efficiency = float(np.median(efficiencies)); q25 = float(np.quantile(efficiencies, .25))
    for ok, name in [(mad <= .12, 'Irregular channel turning points'),
                     (duration_mad <= .50, 'Irregular channel swing spacing'),
                     (efficiency >= .35 and q25 >= .20, 'Choppy channel crossings')]:
        if not ok: reasons.append(name)
    trend_widths = slope*(n-1)/width
    direction = 'rising' if trend_widths > .25 else 'falling' if trend_widths < -.25 else 'horizontal'
    m = dict(channelShape=True, formationBars=n, daysCovered=n,
             channelDirection=direction, channelSlopeLogPerDay=slope,
             channelStartTrendLog=mean-slope*(n-1)/2,
             channelResidualLowLog=float(lo), channelResidualHighLog=float(hi),
             channelWidthLog=width, channelWidthPct=100*math.expm1(width),
             channelTrendMovePct=100*math.expm1(slope*(n-1)),
             boundaryShiftWidths=shift, extremaMADWidths=mad,
             thirdResidualDriftWidths=max(drift), swingDurationMadRatio=duration_mad,
             medianCrossingDays=median_duration, transitions=len(states)-1,
             confirmedLows=len(lows), confirmedHighs=len(highs),
             swingEfficiencyMedian=efficiency, swingEfficiencyQ25=q25)
    return m, reasons


def order(row):
    m = row['metrics']
    return (m['boundaryShiftWidths'], m['extremaMADWidths'],
            -m['swingEfficiencyMedian'], -m['formationBars'], row['pair'])


def search(owner):
    if owner.frame != 'daily':
        raise ValueError('Consistent channels uses daily context only')
    out = []; rejected = Counter(); coverage = {}
    for n in WINDOWS:
        eligible = [r for r in owner.rows if len(r['bars']) >= n+1 and daily_bars_valid(r['bars'], n+1)]
        c = coverage[str(n)] = dict(contracts=len(eligible),
            pairComparisons=len(eligible)*(len(eligible)-1)//2, prefilterPassed=0, matches=0)
        if len(eligible) < 2:
            owner.warnings.append(str(n)+'-day channel window unavailable: fewer than two contracts have sufficient complete saved history.')
            continue
        logs = np.log(np.array([[b[4] for b in r['bars'][-n-1:-1]] for r in eligible]))
        t = np.arange(n)-(n-1)/2
        # Every unordered pair is included here, including trending ratios.
        # Vectorized necessary-condition gates save scalar pivot work only.
        for i, A in enumerate(eligible[:-1]):
            x = logs[i]-logs[i+1:]; centered = x-x.mean(axis=1, keepdims=True)
            slopes = centered@t/(t@t); residual = centered-slopes[:, None]*t
            lo, hi = np.quantile(residual, [.1, .9], axis=1); w = hi-lo
            safe = np.where(w > 0, w, 1)
            thirds = [residual[:, k*n//3:(k+1)*n//3] for k in range(3)]
            bounds = np.array([np.quantile(v, [.1, .9], axis=1) for v in thirds])
            shift = np.maximum(np.ptp(bounds[:, 0, :], axis=0), np.ptp(bounds[:, 1, :], axis=0))/safe
            widths = (bounds[:, 1, :]-bounds[:, 0, :])/safe
            good = (w >= math.log(1.1)) & (shift <= .25) & np.all((widths >= .65) & (widths <= 1.5), axis=0)
            for v in thirds:
                q = np.arange(v.shape[1])-(v.shape[1]-1)/2
                drift = np.abs((v-v.mean(axis=1, keepdims=True))@q/(q@q)*(v.shape[1]-1))/safe
                good &= drift <= .50
            c['prefilterPassed'] += int(sum(good))
            for j in np.flatnonzero(good):
                B = eligible[i+1+int(j)]; m, reasons = channel_fit(x[j])
                if reasons:
                    rejected.update(reasons); continue
                c['matches'] += 1
                # Canonical chart ratio: these fields do not recommend a trade.
                L, S = A['symbol'], B['symbol']; a, b = A['bars'], B['bars']
                fit_start = a[-n-1][6]
                if fit_start != b[-n-1][6] or a[-1][6] != b[-1][6]:
                    raise ValueError('Unsynchronized daily channel candles')
                latest = math.log(a[-1][4]/b[-1][4])
                floor = m['channelStartTrendLog']+m['channelResidualLowLog']
                latest_pos = (latest-(floor+m['channelSlopeLogPerDay']*n))/m['channelWidthLog']
                ctx = owner.context(L, S); current_pos = None
                if ctx['currentRatio']:
                    now = (owner.meta['serverTime']-fit_start)/DAY
                    current_pos = (math.log(ctx['currentRatio'])-(floor+m['channelSlopeLogPerDay']*now))/m['channelWidthLog']
                m.update(channelFitStartCloseTime=fit_start, channelStepMs=DAY,
                         channelCompletedPositionPct=100*latest_pos,
                         channelMarkPositionPct=100*current_pos if current_pos is not None else None,
                         channelLatestOutside=not 0 <= latest_pos <= 1,
                         channelMarkOutside=None if current_pos is None else not 0 <= current_pos <= 1)
                out.append(owner.row(L, S, m, m['swingEfficiencyMedian'],
                    stage=m['channelDirection'].capitalize()+' channel · chart ratio only, no entry signal'))
    groups = defaultdict(list)
    for row in out: groups[(row['long'], row['short'])].append(row)
    rows = []
    for matches in groups.values():
        row = min(matches, key=order); m = row['metrics']
        m['passingWindows'] = sorted(p['metrics']['formationBars'] for p in matches)
        m['channelWindowDirections'] = [str(p['metrics']['formationBars'])+'d: '+p['metrics']['channelDirection'] for p in sorted(matches, key=lambda p:p['metrics']['formationBars'])]
        m['channelDirectionConflict'] = len({p['metrics']['channelDirection'] for p in matches}) > 1
        rows.append(row)
    owner.counts = {**coverage, 'pipeline': dict(passingPairWindows=len(out),
        uniquePairsBeforeHeldExclusion=len(rows)), 'scalarRejections': dict(rejected)}
    owner.warnings += ['Descriptive parallel channels fitted to daily log-close ratios. Horizontal, rising and falling structures are included; no slope, edge, confirmation or current-quote eligibility gate.',
        'A one-way trend alone does not pass: repeated detrended swings, stable boundaries, regular extrema/spacing and efficient crossings are required.',
        'Latest close/mark outside the channel and differing horizon directions remain visible cautions, not hidden exclusions. Chart numerator/denominator are not trade instructions.',
        'Fitted whole-window lines were not available at earlier points in that window. No channel persistence, future return or funding/cost eligibility established.']
    return sorted(rows, key=order)
