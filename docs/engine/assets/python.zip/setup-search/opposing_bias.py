"""Opposing coin biases from unique confirmed setup pairs; no learned weights."""
from collections import defaultdict


def count_votes(rows):
    grouped = defaultdict(list)
    for p in rows:
        if p['long'] != p['short'] and p['metrics'].get('structureConfirmed') is True:
            grouped[(p['long'], p['short'])].append(p)
    conflicts = {tuple(sorted(k)) for k in grouped if (k[1], k[0]) in grouped}
    coins, direct = {}, {}
    for (L, S), matches in sorted(grouped.items()):
        if tuple(sorted((L, S))) in conflicts:
            continue
        families = sorted({f['family'] for p in matches for f in p['familyMatches']
                           if f['metrics'].get('structureConfirmed') is True})
        if not families:
            continue
        evidence = {'long': L, 'short': S, 'families': families}
        direct[(L, S)] = evidence
        for token, other, side in [(L, S, 'long'), (S, L, 'short')]:
            c = coins.setdefault(token, {'symbol': token, 'long': 0, 'short': 0,
                 'rangeLong': 0, 'rangeShort': 0, 'extremeLong': 0, 'extremeShort': 0,
                 'counterparts': []})
            c[side] += 1
            if any('range' in f.lower() for f in families):
                c['range'+side.title()] += 1
            if 'Extreme recovery' in families:
                c['extreme'+side.title()] += 1
            c['counterparts'].append({'other': other, 'direction': side, **evidence})
    for c in coins.values():
        c['net'] = c['long']-c['short']
        c['total'] = c['long']+c['short']
        c['dominantAgreementPct'] = 100*max(c['long'], c['short'])/c['total']
    return coins, direct, len(conflicts)


def opposing_rows(coins, direct, context):
    rows = []
    longs = sorted((c for c in coins.values() if c['net'] > 0), key=lambda c:c['symbol'])
    shorts = sorted((c for c in coins.values() if c['net'] < 0), key=lambda c:c['symbol'])
    for a in longs:
        for b in shorts:
            L, S = a['symbol'], b['symbol']
            if context(L, S)['currentRatio'] is None:
                continue
            x, y = a['net'], -b['net']
            score = 2*x*y/(x+y)
            hit = direct.get((L, S))
            metrics = {'opposingBias': True, 'longCoinLongVotes': a['long'],
                'longCoinShortVotes': a['short'], 'longCoinNetVotes': x,
                'shortCoinLongVotes': b['long'], 'shortCoinShortVotes': b['short'],
                'shortCoinNetVotes': -y, 'balancedNetVotes': score,
                'combinedNetVotes': x+y,
                'minimumAgreementPct': min(a['dominantAgreementPct'], b['dominantAgreementPct']),
                'longCoinRangeLongVotes': a['rangeLong'], 'longCoinRangeShortVotes': a['rangeShort'],
                'shortCoinRangeLongVotes': b['rangeLong'], 'shortCoinRangeShortVotes': b['rangeShort'],
                'longCoinExtremeLongVotes': a['extremeLong'], 'longCoinExtremeShortVotes': a['extremeShort'],
                'shortCoinExtremeLongVotes': b['extremeLong'], 'shortCoinExtremeShortVotes': b['extremeShort'],
                'directSetupConfirmed': bool(hit), 'structureConfirmed': bool(hit),
                'directSetupFamilies': hit['families'] if hit else []}
            rows.append({'long': L, 'short': S, 'pair': L[:-4]+'/'+S[:-4],
                'metrics': metrics, 'score': score,
                'stage': 'Opposing bias · direct setup confirmed' if hit else
                         'Watch: opposing coin biases only · pair setup unconfirmed'})
    return sorted(rows, key=lambda p:(-p['score'], -p['metrics']['combinedNetVotes'],
                  -p['metrics']['minimumAgreementPct'], p['pair']))


def search(owner):
    from engine import Search
    from first20 import search as first20_search
    source = Search(owner.path, 'daily')
    matches = first20_search(source)
    coins, direct, conflicts = count_votes(matches)
    owner.counts = {**source.counts, 'uniqueConfirmedVotePairs': len(direct),
                   'oppositeDirectionPairsAbstained': conflicts,
                   'coinsWithVotes': len(coins),
                   'longBiasedCoins': sum(c['net']>0 for c in coins.values()),
                   'shortBiasedCoins': sum(c['net']<0 for c in coins.values()),
                   'zeroNetCoins': sum(c['net']==0 for c in coins.values())}
    owner.bias_evidence = {'source': 'Confirmed families of fixed daily/4h First20-style composite',
        'sourcePriceMatches': len(matches), 'uniqueConfirmedVotePairs': len(direct),
        'oppositeDirectionPairsAbstained': conflicts,
        'coins': sorted(coins.values(), key=lambda c:(-abs(c['net']), c['symbol']))}
    owner.warnings += [
        'Counts use unique confirmed setup pairs from the combined daily/4h search, not every catalog model. Watch-only setups contribute no votes.',
        'Votes are calculated across the full source universe before held-coin exclusion. Multiple families/windows count once; opposite-direction pair conflicts abstain.',
        'Ranking balances BOTH net directional vote counts. Counts share tokens and market events, and differing history coverage; they are not independent probabilities.',
        'A combination of biased coins may lack its own qualifying setup. These rows remain Watch; direct pair confirmation is labelled separately.',
        'Snapshot observations only. Funding, costs, neutral exposure and future profit are not established.'
    ]
    rows = opposing_rows(coins, direct, source.context)
    for p in rows:
        p['frame'] = owner.frame
    return rows
