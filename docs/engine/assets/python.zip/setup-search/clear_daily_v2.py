"""Descriptive daily range edges with explicit smoothness and modest confirmation.

V2 contract: research/clear_daily_edges_v2_2026-10-20/contract.json.
V1 helpers and archived behavior remain preserved in clear_daily.py.
No fills, expected returns, ratio wicks or funding clearance are inferred.
"""
import math
from collections import Counter, defaultdict
import numpy as np
from trend_range import daily_bars_valid


from clear_daily import swing_quality, leg_quality


def recent_chop(values, width):
    x = np.asarray(values, float)
    if len(x) < 30 or not np.isfinite(x).all() or not width > 0:
        return None, ['Missing recent daily closes']
    x = x[-30:]
    residual = np.array([abs(x[i]-np.median(x[i-1:i+2]))/width for i in range(1, 29)])
    median, p90 = float(np.median(residual)), float(np.quantile(residual, .9))
    return dict(recentChopDays=30, recentChopMedianBandPct=100*median,
                recentChopP90BandPct=100*p90), [name for ok, name in [
        (median <= .08, 'Recent median zigzag noise'),
        (p90 <= .20, 'Recent upper-tail zigzag noise')] if not ok]


def timing_bars_valid(bars, minimum=21):
    a = np.asarray(bars, float); step = 4*60*60*1000
    if a.ndim != 2 or a.shape[1] != 7 or len(a) < minimum or not np.isfinite(a).all():
        return False
    return bool(np.all(a[:, 1:5] > 0) and np.all(a[:, 5] >= 0)
                and np.all(a[:, 2] >= np.max(a[:, [1, 3, 4]], axis=1))
                and np.all(a[:, 3] <= np.min(a[:, [1, 2, 4]], axis=1))
                and np.all(np.diff(a[:, 0]) == step) and np.all(a[:, 0] % step == 0)
                and np.all(a[:, 6]-a[:, 0] == step-1))


def edge_turn(values, lo, width, mark):
    y = np.asarray(values, float)
    if len(y) < 21 or not np.isfinite(y).all() or not width > 0 or not math.isfinite(mark):
        return None, ['Missing completed4h turn or quote']
    idx = len(y)-18+int(np.flatnonzero(y[-18:] == min(y[-18:]))[-1])
    low = float(y[idx]); age = len(y)-1-idx; rebound = float(y[-1]-low)
    close_pos = float((y[-1]-lo)/width); mark_pos = (mark-lo)/width
    retained = (mark-low)/rebound if rebound > 0 else None
    pre = bool(y[-1] > max(y[idx-3:idx]))
    higher = any(y[k] < y[k-1] and y[k] < y[k+1]
                 and y[k]-low >= .015*width and y[-1] > max(y[idx+1:k])
                 for k in range(idx+2, len(y)-1))
    m = dict(locationPct=100*mark_pos, completed4hLocationPct=100*close_pos,
             lowAgeTimingBars=age, reboundBandPct=100*rebound/width,
             reboundRetainedPct=100*retained if retained is not None else None,
             structureConfirmed=bool(pre or higher), confirmation4h='Pre-trough break' if pre else 'Higher-low break' if higher else 'Unconfirmed')
    tests = [(0 <= close_pos <= .20, 'Completed4h close outside outer20%'),
             (0 <= mark_pos <= .20, 'Current mark outside outer20%'),
             (-.10 <= (low-lo)/width <= .10, '4h trough not near daily edge'),
             (2 <= age <= 15, '4h trough not2–15bars old'),
             (rebound >= .03*width, '4h rebound below3%of daily band'),
             (y[-1] > y[-4] and y[-1] >= np.mean(y[-4:-1]), '4h recovery not holding'),
             (pre or higher, '4h structure break unconfirmed'),
             (retained is not None and retained >= .8, 'Current mark gave back turn')]
    return m, [reason for ok, reason in tests if not ok]


def order(row):
    m = row['metrics']
    return (-m['swingEfficiencyMedian'], -m['rangeQualityScore'],
            m['locationPct'], -m['formationBars'], row['pair'])


def search(owner, timing=None):
    if owner.frame != 'daily':
        raise ValueError('Clear range edges uses daily candles only')
    if timing is None:
        from engine import Search
        timing = Search(owner.path, 'four')
    if not (owner.cut <= timing.cut < owner.cut+86400000 and timing.cut <= owner.meta['serverTime']):
        raise ValueError('4h confirmation clock outside saved daily/quote boundary')
    base = owner.ranges(True, [180, 360]); rejected = Counter(); out = []
    owner.counts = {**base['counts'], 'pipeline': {
        'strictRangeWindows': len(base['rows']), 'clearShapeWindows': 0,
        'smoothWindows': 0, 'validLegHistoryWindows': 0, 'practicalWindows': 0, 'confirmedEdgeWindows': 0}}
    pipeline = owner.counts['pipeline']; quality = {}
    # Never relax the fixed contract to produce more matches.
    for g in base['rows']:
        A, B, n, width = g['a'], g['b'], g['bars'], g['widthLog']
        if g['drift'] > .25 or g['shift'] > .25 or g['mad'] > .12:
            rejected['Unclear boundaries'] += 1; continue
        pipeline['clearShapeWindows'] += 1
        a, b = owner.by[A]['bars'], owner.by[B]['bars']
        for sym, bars in [(A, a), (B, b)]:
            if sym not in quality:
                quality[sym] = leg_quality(bars)
        if not daily_bars_valid(a, n+1) or not daily_bars_valid(b, n+1):
            rejected['Incomplete formation OHLCV'] += 1; continue
        x = owner.series(A, B)
        smooth, reasons = swing_quality(x[-n-1:-1], g['loLog'], width)
        reasons = [r for r in reasons if r not in ['Large typical daily ratio jumps', 'One daily ratio jump dominates']]
        chop, chop_reasons = recent_chop(x, width)
        if reasons or chop_reasons:
            rejected.update(reasons+chop_reasons); continue
        pipeline['smoothWindows'] += 1
        if any(quality[s][0] is None for s in [A, B]):
            rejected['Invalid daily leg history'] += 1; continue
        if any(s not in timing.by or not timing_bars_valid(timing.by[s]['bars']) for s in [A, B]):
            rejected['Missing or invalid4h history'] += 1; continue
        pipeline['validLegHistoryWindows'] += 1
        z = timing.series(A, B)
        ctx = owner.context(A, B)
        if not ctx['currentRatio']:
            rejected['Missing fresh synchronized marks'] += 1; continue
        if any(l['volume30USDT'] is None or l['volume30USDT'] < 2e6
               or l['spreadPct'] is None or l['spreadPct'] > .15 for l in ctx['legs']):
            rejected['Insufficient liquidity or spread'] += 1; continue
        pipeline['practicalWindows'] += 1
        cur = math.log(ctx['currentRatio'])
        for direction in [1, -1]:
            lo = g['loLog'] if direction == 1 else -g['hiLog']
            turn, reasons = edge_turn(direction*z, lo, width, direction*cur)
            if reasons:
                rejected.update(reasons); continue
            pipeline['confirmedEdgeWindows'] += 1
            L, S = (A, B) if direction == 1 else (B, A)
            metrics = {**smooth, **chop, **turn, 'clearDailyEdge': True, 'clearDailyRevision': 2,
                       'completedCloseLocationPct': 100*(direction*x[-1]-lo)/width,
                       'legCautions': [sym[:-4]+': '+r for sym in [L, S] for r in quality[sym][1]],
                       'sourceEdge': 'bottom' if direction == 1 else 'top',
                       'sourcePair': A[:-4]+'/'+B[:-4],
                       'formationBars': n, 'daysCovered': n,
                       'bandLow': math.exp(lo), 'bandHigh': math.exp(lo+width),
                       'rangeQualityScore': g['score'], 'driftWidths': g['drift'],
                       'boundaryShiftWidths': g['shift'], 'extremaMADWidths': g['mad'],
                       'transitions': g['transitions'],
                       'confirmedLows': g['lows'], 'confirmedHighs': g['highs'],
                       'structureConfirmed': True, 'timingFrame': 'four',
                       'timingLastClose': timing.cut-1, 'dailyContextLastClose': owner.cut-1,
                       'longLegQuality': quality[L][0], 'shortLegQuality': quality[S][0],
                       'maxLegWick95Pct': max(quality[s][0]['wick95Pct'] for s in [L, S]),
                       'maxLegWickPct': max(quality[s][0]['wickMaxPct'] for s in [L, S]),
                       'maxLegCloseJump95Pct': max(quality[s][0]['closeJump95Pct'] for s in [L, S]),
                       'maxLegCloseJumpPct': max(quality[s][0]['closeJumpMaxPct'] for s in [L, S]),
                       'fundingEligibility': 'unverified'}
            out.append(owner.row(L, S, metrics, g['score'], geometry=g,
                                 stage='Daily range +4h turn · costs unverified'))
    # Conflicting window directions are not two independent opportunities.
    groups = defaultdict(list)
    for p in out:
        groups[tuple(sorted([p['long'], p['short']]))].append(p)
    rows = []
    for candidates in groups.values():
        if len({p['long'] for p in candidates}) > 1:
            rejected['Conflicting window directions'] += 1; continue
        p = min(candidates, key=order)
        p['metrics']['passingWindows'] = sorted({q['metrics']['formationBars'] for q in candidates})
        rows.append(p)
    owner.counts['rejections'] = dict(rejected)
    owner.counts['pipeline']['uniquePairsBeforeHeldExclusion'] = len(rows)
    owner.warnings += [
        'V2 exploratory screen: unchanged strict180/360 DAILY context and structural swings; recent30-day zigzag noise; completed4h structure confirmation. No performance validation.',
        'Completed4h close AND synchronized snapshot mark must remain inside the outer20%of the daily fitted band. Daily close is context only. Tops invert long/short.',
        'Individual-leg wick/jump limits are caution flags, not rejection gates. Whole-formation daily jump caps are metrics only. Valid consecutive OHLCV and liquidity remain required.',
        'Rejection labels overlap; later gates are not evaluated after earlier failure. Fitted quantile edges are not guaranteed support/resistance. Funding and execution costs remain unverified.']
    return sorted(rows, key=order)
