"""Daily structural uptrend inspired by the owner's DOGE/SHELL daily chart.
New descriptive hypothesis. No sideways-range prerequisite, hourly signal or P&L claim.
"""
import math
import numpy as np
LIMITS={180:(15.,30.),360:(25.,40.)}

def window_metrics(values,n):
 x=np.asarray(values,float)
 if len(x)<n+1 or not np.isfinite(x[-n-1:]).all():return None,['Missing daily trend history']
 x=x[-n-1:];t=np.arange(n+1)-n/2;y=x-x.mean();ss=float(y@y);tt=float(t@t);cov=float(t@y);slope=cov/tt;r2=cov*cov/(tt*ss)if ss>0 else 0.;delta=np.diff(x);net=float(x[-1]-x[0]);dd=float(np.max(np.maximum.accumulate(x)-x));pos=float(np.maximum(delta,0).sum());blocks=np.diff(x[::30]);bp=float(np.maximum(blocks,0).sum());q=np.array([np.quantile(x[k*n//3:(k+1)*n//3],[.2,.8])for k in range(3)]);higher=bool(np.all(np.diff(q,axis=0)>0));rolling=float(np.mean(x[30:]>x[:-30]));blockshare=float(np.mean(blocks>0));single=float(max(delta)/pos)if pos>0 else 1.;singleblock=float(max(blocks)/bp)if bp>0 else 1.;gain=100*math.expm1(net);ddpct=100*(-math.expm1(-dd));min_gain,maxdd=LIMITS[n]
 tests=[(slope>0 and r2>=.60,'Weak or falling daily trend'),(gain>=min_gain,'Insufficient multi-month rise'),(ddpct<=maxdd,'Excessive daily-close drawdown'),(higher,'Daily floors/ceilings not rising across thirds'),(rolling>=.60,'Too few rising rolling30-day windows'),(blockshare>=.55,'Too few positive30-day blocks'),(single<=.15,'One positive day dominates'),(singleblock<=.50,'One30-day burst dominates')]
 return {'days':n,'gainPct':gain,'logTrendR2':r2,'logSlopePerDay':slope,'closeDrawdownPct':ddpct,'rolling30PositivePct':100*rolling,'positive30DayBlocks':int(np.sum(blocks>0)),'total30DayBlocks':len(blocks),'positive30DayBlocksPct':100*blockshare,'dailyGreenClosesPct':100*float(np.mean(delta>0)),'higherThirdFloorsCeilings':higher,'thirdQ20':list(map(float,q[:,0])),'thirdQ80':list(map(float,q[:,1])),'largestPositiveDaySharePct':100*single,'largestPositive30DayBlockSharePct':100*singleblock},[name for hit,name in tests if not hit]

def daily_metrics(values):
 x=np.asarray(values,float)
 if len(x)<361 or not np.isfinite(x[-361:]).all():return None,['Missing361 consecutive daily closes']
 windows={};reasons=[]
 for n in [180,360]:
  m,r=window_metrics(x,n);windows[str(n)]=m;reasons.extend(str(n)+'d: '+s for s in r)
 pullback=100*(-math.expm1(float(x[-1]-max(x[-361:]))));ret60=100*math.expm1(float(x[-1]-x[-61]));ratio=np.exp(x[-90:]);sma20=float(np.mean(ratio[-20:]));sma90=float(np.mean(ratio))
 if pullback>25:reasons.append('Latest close more than25% below annual close peak')
 if ret60< -15:reasons.append('Latest60-day fall exceeds15%')
 return {'dailyTrendPass':not reasons,'dailyContextDays':360,'dailyGain180Pct':windows['180']['gainPct'],'dailyGain360Pct':windows['360']['gainPct'],'dailyTrendR2Min':min(m['logTrendR2']for m in windows.values()),'dailyDrawdown180Pct':windows['180']['closeDrawdownPct'],'dailyDrawdown360Pct':windows['360']['closeDrawdownPct'],'rolling30Positive360Pct':windows['360']['rolling30PositivePct'],'positiveMonthBlocks360':windows['360']['positive30DayBlocks'],'dailyGreenCloses360Pct':windows['360']['dailyGreenClosesPct'],'currentPullback360Pct':pullback,'ratio60DayPct':ret60,'dailySMA20':sma20,'dailySMA90':sma90,'currentAboveDailySMA20':bool(ratio[-1]>sma20),'currentAboveDailySMA90':bool(ratio[-1]>sma90),'dailyWindows':windows},reasons

def daily_leg_quality(bars):
 a=np.asarray(bars,float)
 if a.ndim!=2 or len(a)<361 or a.shape[1]<7:return None,['Missing daily leg history']
 a=a[-361:];step=86400000
 if not np.isfinite(a).all()or np.any(a[:,1:5]<=0)or np.any(a[:,5]<0):return None,['Invalid daily OHLC']
 if np.any(a[:,2]<np.max(a[:,[1,3,4]],axis=1))or np.any(a[:,3]>np.min(a[:,[1,2,4]],axis=1)):return None,['Invalid daily OHLC']
 if not np.all(np.diff(a[:,0])==step)or not np.all(a[:,6]-a[:,0]==step-1)or not np.all(a[:,0]%step==0):return None,['Gapped daily candles']
 v=a[-30:];tail=np.maximum(np.log(v[:,2]/np.maximum(v[:,1],v[:,4])),np.log(np.minimum(v[:,1],v[:,4])/v[:,3]));p95=100*math.expm1(float(np.quantile(tail,.95)));mx=100*math.expm1(float(max(tail)));r=[]
 if p95>8:r.append('Frequent large daily leg tails')
 if mx>15:r.append('Extreme recent daily leg tail')
 return {'dailyLegTailP95Pct':p95,'dailyLegTailMaxPct':mx},r
