"""Exploratory composite of documented first-20 setup families, never outcome-fitted.

Fixed daily/4h clocks. Existing range, pump and extreme gates remain unchanged.
See research/first20_search_2026-10-20/contract.json for provenance and limits.
"""
import math
import numpy as np


def range_turn(y, lo, width):
    """The existing range-reversal proxy; absence is unknown, not confirmation."""
    if len(y) < 21 or not np.isfinite(y).all() or width <= 0:
        return {'structureConfirmed': None, 'timingUnavailable': True}
    start = len(y) - 18
    mini = min(y[start:])
    idx = start + int(np.flatnonzero(y[start:] == mini)[-1])
    age = len(y) - 1 - idx
    pos = (y[-1] - lo) / width
    rebound = (y[-1] - mini) / width
    early = (.10 <= pos <= .42 and (mini-lo)/width <= .15
             and 2 <= age <= 15 and rebound >= .08
             and y[-1] > y[-4] and y[-1] >= y[-2] - .01*width
             and y[-1] >= np.mean(y[-4:-1]))
    pre = y[-1] > max(y[idx-3:idx])
    higher = any(y[k] < y[k-1] and y[k] < y[k+1]
                 and y[k]-mini >= .015*width
                 and y[-1] > max(y[idx+1:k])
                 for k in range(idx+2, len(y)-1))
    return {'structureConfirmed': bool(early and (pre or higher)),
            'lowAgeTimingBars': age, 'reboundBandPct': float(rebound*100),
            'timingFrame': 'four'}


def merge_matches(rows):
    """Retain all supporting families, without double-counting an oriented pair."""
    groups = {}
    for row in rows:
        groups.setdefault((row['long'], row['short']), []).append(row)
    out = []
    for key, matches in groups.items():
        def order(p):
            m = p['metrics']
            return (m.get('structureConfirmed') is True,
                    m.get('strictRangePass') is True,
                    m.get('rangeQualityScore', 0), m.get('formationBars', 0))
        primary = max(matches, key=order)
        p = {**primary, 'metrics': dict(primary['metrics'])}
        m = p['metrics']
        m['first20Style'] = True
        m['setupFamilies'] = sorted({r['metrics']['setupFamily'] for r in matches})
        m['matchingFamilies'] = len(m['setupFamilies'])
        m['structureConfirmed'] = any(r['metrics'].get('structureConfirmed') is True for r in matches)
        m['strictRangePass'] = any(r['metrics'].get('strictRangePass') is True for r in matches)
        m['rangeQualityScore'] = max(r['metrics'].get('rangeQualityScore', 0) for r in matches)
        p['familyMatches'] = [{'family': r['metrics']['setupFamily'],
                              'metrics': r['metrics']} for r in matches]
        p['stage'] = ('Confirmed turn · ' if m['structureConfirmed'] else 'Watch: waiting for turn · ') + ' + '.join(m['setupFamilies'])
        p['score'] = m['rangeQualityScore']
        out.append(p)
    keys = set(groups)
    for p in out:
        conflict = (p['short'], p['long']) in keys
        p['metrics']['horizonDirectionsConflict'] = conflict
        if conflict:
            p['stage'] += ' · opposite horizon also matches'
    return sorted(out, key=lambda p: (-int(p['metrics']['structureConfirmed']),
                  -int(p['metrics']['strictRangePass']),
                  -p['metrics']['rangeQualityScore'], p['pair']))


def search(owner):
    # Import lazily to avoid a cycle. Detail frame never compresses formation.
    from engine import Search, geometry
    daily = Search(owner.path, 'daily')
    four = Search(owner.path, 'four')
    rows, counts = [], {}
    for ctx, windows in [(daily, [90, 180, 360]), (four, [180, 360])]:
        base = ctx.ranges(False, windows)
        for bars, coverage in base['counts'].items():
            counts[ctx.frame+'_'+bars+'_bars'] = coverage
        for g in base['rows']:
            A, B = g['a'], g['b']
            live = daily.context(A, B)['currentRatio']
            if live is None:
                continue
            x = ctx.series(A, B)
            live_pos = (math.log(live)-g['loLog'])/g['widthLog']
            d = 1 if live_pos <= .5 else -1
            L, S = (A, B) if d == 1 else (B, A)
            lo = g['loLog'] if d == 1 else -g['hiLog']
            pos = (math.log(live)*d-lo)/g['widthLog']
            close_pos = (x[-1]*d-lo)/g['widthLog']
            if not (-.1 <= pos <= .4 and -.1 <= close_pos <= .4):
                continue
            strict = geometry(x[-g['bars']-1:-1], x[-1], True)
            is_strict = bool(strict and strict['pass'])
            turn = (range_turn(four.series(L, S), lo, g['widthLog'])
                    if L in four.by and S in four.by else
                    {'structureConfirmed': None, 'timingUnavailable': True})
            family = ('Strict' if is_strict else 'Broad') + ' ' + ('daily' if ctx.frame == 'daily' else '4h') + ' range'
            metrics = {'setupFamily': family, 'formationFrame': ctx.frame,
                       'formationBars': g['bars'], 'daysCovered': g['bars']*ctx.step/86400000,
                       'locationPct': float(pos*100), 'closedLocationPct': float(close_pos*100),
                       'rangeQualityScore': g['score'], 'strictRangePass': is_strict,
                       'transitions': g['transitions'], 'confirmedLows': g['lows'],
                       'confirmedHighs': g['highs'], 'driftWidths': g['drift'],
                       'boundaryShiftWidths': g['shift'],
                       'bandLow': math.exp(lo), 'bandHigh': math.exp(lo+g['widthLog']),
                       **turn}
            rows.append(daily.row(L, S, metrics, g['score'], geometry=g))
    counts['rangeWindowMatches'] = len(rows)
    for name, found in [('Extreme recovery', daily.extreme()),
                        ('Pump recovery', daily.pump({}))]:
        counts[name.replace(' ', '')] = {'matches': len(found)}
        for p in found:
            L, S = p['long'], p['short']
            if daily.context(L, S)['currentRatio'] is None:
                continue
            m = dict(p['metrics'])
            m.update(setupFamily=name, rangeQualityScore=0, strictRangePass=False)
            if name == 'Pump recovery':
                # Pump qualification alone does not prove a confirmed turn.
                m['structureConfirmed'] = False
                if L in four.by and S in four.by:
                    y = four.series(L, S)
                    m['ratio4hPct'] = float(100*math.expm1(y[-1]-y[-2])) if len(y)>=2 else None
                    m['ratio24hPct'] = float(100*math.expm1(y[-1]-y[-7])) if len(y)>=7 else None
            p['metrics'] = m
            rows.append(p)
    owner.counts = counts
    owner.warnings += [
        'Exploratory first-20-style composite, not an exact replica of the original manual choices or a validated strategy.',
        'Daily and 4h contexts stay fixed; the dropdown changes chart detail only. Range floors/ceilings are retrospective fits, not guaranteed support.',
        'Watch rows have no confirmed turn. Costs and full funding eligibility remain unverified; inspect both coins and their execution context.',
        'Shared tokens and overlapping families are dependent. Relative ranking does not estimate future profit.'
    ]
    result = merge_matches(rows)
    for p in result:
        p['frame'] = owner.frame
    return result
