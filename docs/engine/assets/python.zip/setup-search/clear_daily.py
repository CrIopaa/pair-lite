"""Descriptive daily range edges with explicit smoothness and modest confirmation.

Frozen before screening: research/clear_daily_edges_2026-10-20/contract.json.
No fills, expected returns, ratio wicks or funding clearance are inferred.
"""
import math
from collections import Counter, defaultdict
import numpy as np
from trend_range import daily_bars_valid


def swing_quality(values, lo, width):
    x = np.asarray(values, float)
    if len(x) < 30 or not np.isfinite(x).all() or not width > 0:
        return None, ['Missing valid formation closes']
    # Endpoints are synchronous daily closes, never the two legs' high/low ratio.
    crossings = []
    start = side = None
    for i, v in enumerate(x):
        s = -1 if v <= lo + .2*width else 1 if v >= lo + .8*width else 0
        if s and side is None:
            side, start = s, i
        elif s and s != side:
            path = float(np.abs(np.diff(x[start:i+1])).sum())
            crossings.append(abs(float(x[i]-x[start]))/path if path > 0 else 0.)
            side, start = s, i
    if len(crossings) < 8:
        return None, ['Fewer than8 complete edge crossings']
    steps = np.abs(np.diff(x))/width
    m = dict(swingEfficiencyMedian=float(np.median(crossings)),
             swingEfficiencyQ25=float(np.quantile(crossings, .25)),
             completedSwingCount=len(crossings),
             dailyStep95BandPct=100*float(np.quantile(steps, .95)),
             dailyStepMaxBandPct=100*float(max(steps)))
    tests = [(m['swingEfficiencyMedian'] >= .25, 'Choppy median swing'),
             (m['swingEfficiencyQ25'] >= .15, 'Choppy lower-quarter swings'),
             (m['dailyStep95BandPct'] <= 20, 'Large typical daily ratio jumps'),
             (m['dailyStepMaxBandPct'] <= 45, 'One daily ratio jump dominates')]
    return m, [reason for ok, reason in tests if not ok]


def edge_turn(values, lo, width, mark):
    y = np.asarray(values, float)
    if len(y) < 10 or not np.isfinite(y).all() or not width > 0 or not math.isfinite(mark):
        return None, ['Missing daily turn or current quote']
    idx = len(y)-10+int(np.flatnonzero(y[-10:] == min(y[-10:]))[-1])
    low = float(y[idx]); age = len(y)-1-idx
    close_pos = float((y[-1]-lo)/width); mark_pos = (mark-lo)/width
    rebound = float(y[-1]-low)
    retained = (mark-low)/rebound if rebound > 0 else None
    m = dict(locationPct=100*mark_pos, completedCloseLocationPct=100*close_pos,
             lowAgeDays=age, reboundBandPct=100*rebound/width,
             reboundRetainedPct=100*retained if retained is not None else None,
             twoDailyClosesInward=bool(y[-1] > y[-2] > y[-3]))
    tests = [(0 <= close_pos <= .20, 'Daily close outside outer20%'),
             (0 <= mark_pos <= .20, 'Current mark outside outer20%'),
             (-.10 <= (low-lo)/width <= .10, 'Recent turn not near fitted edge'),
             (2 <= age <= 7, 'Turn low not2–7days old'),
             (rebound >= .03*width, 'Rebound below3%of band'),
             (m['twoDailyClosesInward'], 'Two inward daily closes not confirmed'),
             (retained is not None and retained >= .8, 'Current mark gave back turn')]
    return m, [reason for ok, reason in tests if not ok]


def leg_quality(bars):
    if not daily_bars_valid(bars, 31):
        return None, ['Missing, gapped or malformed daily OHLCV']
    a = np.asarray(bars[-31:], float); b = a[-30:]
    tails = np.maximum(np.log(b[:, 2]/np.maximum(b[:, 1], b[:, 4])),
                       np.log(np.minimum(b[:, 1], b[:, 4])/b[:, 3]))
    jumps = np.abs(np.diff(np.log(a[:, 4])))
    m = dict(wick95Pct=100*math.expm1(float(np.quantile(tails, .95))),
             wickMaxPct=100*math.expm1(float(max(tails))),
             closeJump95Pct=100*math.expm1(float(np.quantile(jumps, .95))),
             closeJumpMaxPct=100*math.expm1(float(max(jumps))))
    tests = [(m['wick95Pct'] <= 5, 'Large typical leg wicks'),
             (m['wickMaxPct'] <= 12, 'Extreme leg wick'),
             (m['closeJump95Pct'] <= 8, 'Large typical leg jumps'),
             (m['closeJumpMaxPct'] <= 15, 'Extreme leg jump')]
    return m, [reason for ok, reason in tests if not ok]


def order(row):
    m = row['metrics']
    return (-m['swingEfficiencyMedian'], -m['rangeQualityScore'],
            m['locationPct'], -m['formationBars'], row['pair'])


def search(owner):
    if owner.frame != 'daily':
        raise ValueError('Clear range edges uses daily candles only')
    base = owner.ranges(True, [180, 360]); rejected = Counter(); out = []
    owner.counts = {**base['counts'], 'pipeline': {
        'strictRangeWindows': len(base['rows']), 'clearShapeWindows': 0,
        'smoothWindows': 0, 'legQualityWindows': 0, 'confirmedEdgeWindows': 0}}
    pipeline = owner.counts['pipeline']; quality = {}
    # Never relax the fixed contract to produce more matches.
    for g in base['rows']:
        A, B, n, width = g['a'], g['b'], g['bars'], g['widthLog']
        if g['drift'] > .25 or g['shift'] > .25 or g['mad'] > .12:
            rejected['Unclear boundaries'] += 1; continue
        pipeline['clearShapeWindows'] += 1
        a, b = owner.by[A]['bars'], owner.by[B]['bars']
        for sym, bars in [(A, a), (B, b)]:
            if sym not in quality:
                quality[sym] = leg_quality(bars)
        if not daily_bars_valid(a, n+1) or not daily_bars_valid(b, n+1):
            rejected['Incomplete formation OHLCV'] += 1; continue
        x = owner.series(A, B)
        smooth, reasons = swing_quality(x[-n-1:-1], g['loLog'], width)
        if reasons:
            rejected.update(reasons); continue
        pipeline['smoothWindows'] += 1
        if any(quality[s][1] for s in [A, B]):
            rejected['Individual leg wick or jump quality'] += 1; continue
        ctx = owner.context(A, B)
        if not ctx['currentRatio']:
            rejected['Missing fresh synchronized marks'] += 1; continue
        if any(l['volume30USDT'] is None or l['volume30USDT'] < 2e6
               or l['spreadPct'] is None or l['spreadPct'] > .15 for l in ctx['legs']):
            rejected['Insufficient liquidity or spread'] += 1; continue
        pipeline['legQualityWindows'] += 1
        cur = math.log(ctx['currentRatio'])
        for direction in [1, -1]:
            lo = g['loLog'] if direction == 1 else -g['hiLog']
            timing, reasons = edge_turn(direction*x, lo, width, direction*cur)
            if reasons:
                rejected.update(reasons); continue
            pipeline['confirmedEdgeWindows'] += 1
            L, S = (A, B) if direction == 1 else (B, A)
            metrics = {**smooth, **timing, 'clearDailyEdge': True,
                       'sourceEdge': 'bottom' if direction == 1 else 'top',
                       'sourcePair': A[:-4]+'/'+B[:-4],
                       'formationBars': n, 'daysCovered': n,
                       'bandLow': math.exp(lo), 'bandHigh': math.exp(lo+width),
                       'rangeQualityScore': g['score'], 'driftWidths': g['drift'],
                       'boundaryShiftWidths': g['shift'], 'extremaMADWidths': g['mad'],
                       'transitions': g['transitions'],
                       'confirmedLows': g['lows'], 'confirmedHighs': g['highs'],
                       'structureConfirmed': True, 'timingFrame': 'daily',
                       'timingLastClose': owner.cut-1,
                       'longLegQuality': quality[L][0], 'shortLegQuality': quality[S][0],
                       'maxLegWick95Pct': max(quality[s][0]['wick95Pct'] for s in [L, S]),
                       'maxLegWickPct': max(quality[s][0]['wickMaxPct'] for s in [L, S]),
                       'maxLegCloseJump95Pct': max(quality[s][0]['closeJump95Pct'] for s in [L, S]),
                       'maxLegCloseJumpPct': max(quality[s][0]['closeJumpMaxPct'] for s in [L, S]),
                       'fundingEligibility': 'unverified'}
            out.append(owner.row(L, S, metrics, g['score'], geometry=g,
                                 stage='Daily edge turn · costs unverified'))
    # Conflicting window directions are not two independent opportunities.
    groups = defaultdict(list)
    for p in out:
        groups[tuple(sorted([p['long'], p['short']]))].append(p)
    rows = []
    for candidates in groups.values():
        if len({p['long'] for p in candidates}) > 1:
            rejected['Conflicting window directions'] += 1; continue
        p = min(candidates, key=order)
        p['metrics']['passingWindows'] = sorted({q['metrics']['formationBars'] for q in candidates})
        rows.append(p)
    owner.counts['rejections'] = dict(rejected)
    owner.counts['pipeline']['uniquePairsBeforeHeldExclusion'] = len(rows)
    owner.warnings += [
        'New descriptive daily screen: smooth swings, individual-leg tails and two inward daily closes. Thresholds are not performance-validated.',
        'Both current marks and completed daily close must remain inside the outer 20% of the fitted band. Top-side matches are inverted; displayed long/short follows the inward turn.',
        'Rejection labels can overlap. Later gates are not evaluated after an earlier rejection.',
        'Fitted 10th/90th-percentile boundaries are not historical extremes or guaranteed support. Daily closes do not establish smooth intraday execution. Full funding and costs remain unverified.']
    return sorted(rows, key=order)
