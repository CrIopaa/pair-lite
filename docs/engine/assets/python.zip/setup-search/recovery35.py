"""Study-identical frozen horizontal episodes, 33–39% recovery research screen."""
from pathlib import Path
import json,math,hashlib,struct,subprocess,os
from collections import Counter
import numpy as np
from daily_confirmed_range import trade_ratio,DAY
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent;STUDY=PROJECT/'research/range_reversal_depth_2026-10-21';VERSION='2026-10-21-frozen-recovery35-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,data):p.write_text(json.dumps(data,separators=(',',':'),allow_nan=False)+'\n')
def native_binary():
 sources=[ROOT/'recovery35_core.cpp',STUDY/'study.cpp'];fingerprint=hashlib.sha256(''.join(sha(p)for p in sources).encode()).hexdigest()[:16];folder=ROOT/'storage/tmp';folder.mkdir(exist_ok=True);binary=folder/('recovery35-'+fingerprint)
 if not binary.exists():
  env=os.environ.copy();env.update(TMPDIR=str(folder),CLANG_MODULE_CACHE_PATH=str(folder/'clang-modules'))
  subprocess.run(['c++','-O3','-std=c++17','-pthread',str(sources[0]),'-o',str(binary)],check=True,capture_output=True,text=True,env=env)
 return binary

def prepare(owner):
 path=owner.path/('computed-'+VERSION);path.mkdir(exist_ok=True)
 expected=json.loads((PROJECT/'research/recovery35_button_2026-10-21/contract.json').read_text())['frozenSourceHashes']
 if any(sha(PROJECT/k)!=v for k,v in expected.items()):raise ValueError('Frozen study source versions changed; review before scanning.')
 sources=[STUDY/'data/matrices.bin',STUDY/'data/manifest.json',owner.path/'daily.json',owner.path/'public.json',ROOT/'recovery35.py',ROOT/'recovery35_core.cpp',STUDY/'study.cpp']+sorted((STUDY/'results').glob('episodes-*.jsonl'))
 fingerprints={str(p):sha(p)for p in sources};statefile=path/'manifest.json'
 if statefile.exists():
  m=json.loads(statefile.read_text())
  if m.get('sourceHashes')==fingerprints and (path/'core.json').exists():
   if m.get('coreSha256')!=sha(path/'core.json')or m.get('matrixSha256')!=sha(path/'matrix.bin'):raise ValueError('Frozen-range derived cache integrity failed')
   return path,m,json.loads((path/'core.json').read_text())
 base=json.loads((STUDY/'data/manifest.json').read_text());assert fingerprints[str(STUDY/'data/matrices.bin')]==base['matrixSha256']
 index={r['sym']:i for i,r in enumerate(base['symbols'])};symbols=sorted(s for s in owner.by if s in index and owner.info[s].get('underlyingType')=='COIN'and owner.info[s].get('contractType')=='PERPETUAL'and owner.info[s].get('quoteAsset')=='USDT')
 excluded=sorted(set(owner.by)-set(symbols));last=owner.cut//DAY-1;D0=base['day0'];T=last-D0+1
 if T<=90:raise ValueError('Insufficient historical context')
 old=np.memmap(STUDY/'data/matrices.bin',dtype='<f8',offset=16,mode='r');N0,T0=base['N'],base['T'];cl0=old[:N0*T0].reshape(N0,T0);op0=old[N0*T0:2*N0*T0].reshape(N0,T0);cl=np.full((len(symbols),T),np.nan);op=cl.copy();used=min(T,T0);new={s:i for i,s in enumerate(symbols)};append=0;invalid=0
 for s,i in new.items():
  cl[i,:used]=cl0[index[s],:used];op[i,:used]=op0[index[s],:used]
  for b in owner.by[s]['bars']:
   t=b[0]//DAY-D0
   if t<T0 or not 0<=t<T:continue
   valid=b[0]%DAY==0 and b[6]==b[0]+DAY-1 and all(isinstance(v,(int,float))and math.isfinite(v)for v in b)and min(b[1:5])>0 and b[2]>=max(b[1],b[3],b[4])and b[3]<=min(b[1],b[4])and b[5]>0 and b[6]<owner.info[s].get('deliveryDate',float('inf'))
   if valid:cl[i,t]=math.log(b[4]);op[i,t]=math.log(b[1]);append+=1
   else:invalid+=1
 with (path/'matrix.bin').open('wb')as f:f.write(struct.pack('<4i',len(symbols),T,0,D0));cl.astype('<f8').tofile(f);op.astype('<f8').tofile(f)
 seeds={}
 for f in sorted((STUDY/'results').glob('episodes-*.jsonl')):
  for e in map(json.loads,f.open()):
   if e['family']!=0 or e['seed']>last:continue
   a,b=base['symbols'][e['a']]['sym'],base['symbols'][e['b']]['sym']
   if a not in new or b not in new:continue
   key=new[a],new[b]
   if key not in seeds or seeds[key]['seed']<e['seed']:seeds[key]=e
 with (path/'seeds.tsv').open('w')as f:
  for (a,b),e in sorted(seeds.items()):f.write(' '.join(map(str,[a,b,e['seed']-D0,e['n'],e['side'],e['floor'],e['width'],e['shift'],e['mad'],e['efficiency']]))+'\n')
 binary=native_binary();subprocess.run([str(binary),str(path/'matrix.bin'),str(path/'seeds.tsv'),str(min(base['day1'],last)-D0),str(path/'core.json')],check=True,capture_output=True,text=True)
 m={'version':VERSION,'sourceHashes':fingerprints,'symbols':symbols,'N':len(symbols),'T':T,'day0':D0,'lastDay':last,'baseLastDay':base['day1'],'appendedDailyBars':append,'invalidAppendBars':invalid,'excludedUnknownStudyUniverse':excluded,'matrixSha256':sha(path/'matrix.bin'),'coreSha256':sha(path/'core.json'),'binarySha256':sha(binary),'studyRule':'Exact frozen C++ fit family0; immutable historical seeds and pre-cutoff prices; only new completed snapshot days appended.'};save(statefile,m)
 return path,m,json.loads((path/'core.json').read_text())

def qualify(state,current_position,last_index):
 r=state['recovery'];p=state['previousRecovery'];lo=state['trough'];first=state['first35Index']
 if not all(math.isfinite(v)for v in [r,p,lo,current_position])or not 0<=r<1 or lo>=1:return None,'Invalid recovery state'
 if not .33<=r<=.39:return None,'Completed daily recovery outside 33–39%'
 if not r>p:return None,'Latest completed reversal is not advancing'
 confirmed=first==last_index
 if first>=0 and not confirmed:return None,'Earlier 35% cross already occurred'
 if not confirmed and r>=7*.05:return None,'No fresh 35% cross'
 live=(current_position-lo)/(1-lo)
 if not .33<=live<=.39:return None,'Current synchronized trade recovery outside 33–39%'
 return (confirmed,live),None

def search(owner):
 if owner.frame!='daily':raise ValueError('35% recovery uses completed DAILY signals only')
 path,m,core=prepare(owner);day=owner.cut;now=owner.meta['serverTime'];quotes={r['symbol']:r for r in owner.public['data'].get('trades',[])}
 if not quotes:raise ValueError('Refresh data: synchronized last-trade quotes are missing')
 rows=[];rejections=Counter();D0=m['day0'];last=m['T']-1
 for e in core['rows']:
  a,b=m['symbols'][e['a']],m['symbols'][e['b']];q=trade_ratio(quotes,a,b,now,day)
  if q is None:rejections['Unavailable synchronized trade quotes']+=1;continue
  pos=(math.log(q)-e['floor'])/e['width'];pos=pos if e['side']>0 else 1-pos
  result,reason=qualify(e,pos,last)
  if reason:rejections[reason]+=1;continue
  confirmed,live=result;L,S=(a,b)if e['side']>0 else(b,a);lowlog=e['floor']if e['side']>0 else -e['floor']-e['width'];w=e['width'];ratio=q if e['side']>0 else 1/q;seedDay=(D0+e['seedIndex'])*DAY;troughDay=(D0+e['troughIndex'])*DAY
  metrics=dict(recovery35Style=True,recovery35Confirmed=confirmed,recovery35Status='Fresh completed 35% cross'if confirmed else'Approaching 35% · not yet confirmed',recoveryCompletedPct=100*e['recovery'],recoveryCurrentPct=100*live,distanceFrom35Pct=abs(100*live-35),previousRecoveryPct=100*e['previousRecovery'],formationBars=e['n'],daysCovered=e['n'],sourcePair=a[:-4]+'/'+b[:-4],sourceEdge='bottom'if e['side']>0 else'top',rangeSeedTime=seedDay,formationStartTime=seedDay-e['n']*DAY,formationEndTime=seedDay-1,rangeSeedDate=str(np.datetime64(int(D0+e['seedIndex']),'D')),episodeAgeDays=last-e['seedIndex'],observedTroughTime=troughDay,observedTroughRatio=math.exp(lowlog+e['trough']*w),retouchReferenceRatio=math.exp(lowlog+(e['trough']+.02)*w),retouchIsStop=False,bandLow=math.exp(lowlog),bandHigh=math.exp(lowlog+w),target80Ratio=math.exp(lowlog+.8*w),target80RatioRoomPct=100*math.expm1(lowlog+.8*w-math.log(ratio)),completedCloseLocationPct=100*e['position'],locationPct=100*pos,currentTradeRatio=ratio,bandWidthPct=100*math.expm1(w),boundaryShiftWidths=e['shift'],extremaMADWidths=e['mad'],boundaryIrregularity=e['shift']+e['mad'],driftWidths=e['drift'],swingEfficiencyMedian=e['efficiency'],swingEfficiencyQ25=e['q25'],transitions=e['transitions'],confirmedLows=e['lows'],confirmedHighs=e['highs'],chartFrozenHistory=True,studySource='Frozen daily v5 through 12 Oct 2026 + appended public snapshot days',currentDayProvisional=True)
  rows.append(owner.row(L,S,metrics,100-abs(100*live-35),stage=metrics['recovery35Status']+' · frozen horizontal range · 80% research target'))
 owner.counts={'pipeline':{**core['counts'],'studiedCurrentContracts':m['N'],'appendedDailyBars':m['appendedDailyBars'],'confirmed':sum(r['metrics']['recovery35Confirmed']for r in rows),'approaching':sum(not r['metrics']['recovery35Confirmed']for r in rows),'qualifyingBeforeHeldExclusion':len(rows)},'rejections':dict(rejections)}
 owner.warnings+=['Same horizontal range family and frozen episode clocks as the reversal-depth study: 90/180/360 daily bars, longest passing seed window, 45-calendar-day spacing. Sloping channels are not mixed into this screen.',
 '33–39% is your new search tolerance, not a separately backtested strategy. Both latest completed recovery and synchronized current trade recovery must lie inside it. Confirmed means a first 35% cross on the latest completed day; 33–35% approaching rows are labelled not yet confirmed. Older crossed episodes are excluded.',
 'Range and trough are causal. Boundaries stay frozen at the original edge visit; recovery starts at the lowest ratio observed since that visit, never the future final bottom. Top visits invert long/short.',
 'The 80% level is a frozen log-range research target. The 2% trough line is a retouch reference, NOT an assigned stop. 90 days was an observation horizon, not a validated holding limit. No orders, automatic exits, sizing, funding/cost qualification or profitability claim.',
 'Snapshot quotes are dated; today is provisional. Current trading universe is intersected with the original verified study universe. All original history is preserved; no missing prices are filled.']
 return sorted(rows,key=order)

def order(row):
 x=row['metrics'];return(not x['recovery35Confirmed'],x['distanceFrom35Pct'],-x['swingEfficiencyMedian'],x['boundaryIrregularity'],-x['formationBars'],row['pair'])

def chart_data(snapshot,L,S):
 path=Path(snapshot)/('computed-'+VERSION);m=json.loads((path/'manifest.json').read_text());a,b=m['symbols'].index(L),m['symbols'].index(S);N,T=m['N'],m['T'];raw=np.memmap(path/'matrix.bin',dtype='<f8',offset=16,mode='r');cl=raw[:N*T].reshape(N,T);valid=np.isfinite(cl[a])&np.isfinite(cl[b]);bad=np.flatnonzero(~valid);start=max(T-721,int(bad[-1])+1 if len(bad)else 0);ix=np.arange(start,T)
 if len(ix)<2:raise ValueError('Completed chart history unavailable')
 aa=np.exp(cl[a,ix]);bb=np.exp(cl[b,ix]);times=[int((m['day0']+t+1)*DAY-1)for t in ix]
 return {'points':[[t,float(x/y)]for t,x,y in zip(times,aa,bb)],'prices':[[t,float(x),float(y)]for t,x,y in zip(times,aa,bb)],'legs':[[t,float(100*x/aa[0]),float(100*y/bb[0])]for t,x,y in zip(times,aa,bb)],'numerator':L,'denominator':S,'frame':'daily','source':'Frozen study prices plus verified appended completed snapshot days; same path as recovery calculation.'}
