"""Retrospective DAILY range drives; actual raw ratio closes, no smoothing.

Frozen contract: research/clean_drive_button_2026-10-21/contract.json.
Existing channel geometry is reused unchanged. No entry/order/position logic.
"""
import copy
import math
from collections import Counter
import numpy as np
from consistent_channels import search as channel_search, channel_fit


def confirmed_pivots(raw, residual, low, width):
    """Phase boundary arrivals confirm extrema; censor first and unfinished phases."""
    raw = np.asarray(raw, float); residual = np.asarray(residual, float)
    if len(raw) != len(residual) or not np.isfinite(raw).all() or not np.isfinite(residual).all() or not width > 0:
        raise ValueError('Invalid drive history')
    phases = []
    for i, value in enumerate(residual):
        side = -1 if value <= low+.2*width else 1 if value >= low+.8*width else 0
        if side and (not phases or side != phases[-1][1]):
            phases.append((i, side))
    pivots = []
    for k in range(1, len(phases)-1):
        a, side = phases[k]; b = phases[k+1][0]; segment = raw[a:b]
        offset = int(np.argmin(segment) if side < 0 else np.argmax(segment))
        pivots.append(dict(index=a+offset, side=side, confirmedAt=b))
    return pivots


def drive_metrics(raw, pivots, width):
    raw = np.asarray(raw, float); tolerance = max(1e-12, width*1e-8)
    if not np.isfinite(raw).all() or not width > 0:
        return None, ['Invalid drive history']
    legs = []; reasons = []
    for a, b in zip(pivots, pivots[1:]):
        start, end = a['index'], b['index']; direction = 1 if a['side'] < 0 else -1
        if not 0 <= start < end < len(raw) or b['side'] != -a['side']:
            return None, ['Invalid completed pivot order']
        path = direction*(raw[start:end+1]-raw[start]); advance = float(path[-1])
        if advance <= tolerance:
            return None, ['Channel swing is not an actual raw-ratio reversal']
        steps = np.diff(path); adverse = steps[steps < -tolerance]
        backtrack = float(-adverse.sum()); giveback = float(max(np.maximum.accumulate(path)-path))
        legs.append(dict(start=start, end=end, direction=direction, confirmationIndex=b['confirmedAt'],
                         netAdvanceLog=advance, adverseDistanceLog=backtrack,
                         opposingSteps=len(adverse), totalSteps=len(steps),
                         backtrackPct=100*backtrack/advance, givebackPct=100*giveback/advance,
                         efficiency=advance/(advance+2*backtrack)))
    up = sum(r['direction'] == 1 for r in legs); down = len(legs)-up
    if len(legs) < 6 or min(up, down) < 3:
        return None, ['Fewer than six completed drives or three each way']
    advance = sum(r['netAdvanceLog'] for r in legs); backward = sum(r['adverseDistanceLog'] for r in legs)
    aggregate = 100*backward/advance; worst = max(r['backtrackPct'] for r in legs)
    giveback = max(r['givebackPct'] for r in legs); opposing = sum(r['opposingSteps'] for r in legs)
    if aggregate > 12.5: reasons.append('Aggregate backtracking above12.5%of net advance')
    if worst > 25: reasons.append('A completed drive backtracks above25%of net advance')
    if giveback > 20: reasons.append('A completed drive gives back above20%of net advance')
    metrics = dict(cleanDrive=True, driveZeroBacktrack=opposing == 0,
                   driveBacktrackPct=aggregate, driveWorstBacktrackPct=worst,
                   driveWorstGivebackPct=giveback, driveCompletedLegs=len(legs),
                   driveUpLegs=up, driveDownLegs=down, driveOpposingSteps=opposing,
                   driveTotalSteps=sum(r['totalSteps'] for r in legs),
                   driveEfficiency=advance/(advance+2*backward),
                   driveZeroBacktrackLegs=sum(r['opposingSteps'] == 0 for r in legs),
                   driveEvidence=legs)
    return metrics, reasons


def quality(raw, geometry):
    raw = np.asarray(raw, float); n = len(raw)
    residual = raw-geometry['channelStartTrendLog']-geometry['channelSlopeLogPerDay']*np.arange(n)
    pivots = confirmed_pivots(raw, residual, geometry['channelResidualLowLog'], geometry['channelWidthLog'])
    tolerance = max(1e-12, geometry['channelWidthLog']*1e-8)
    for p in pivots:
        i, side = p['index'], p['side']
        around = side*(raw[i]-raw[[i-1, i+1]])
        if min(around) < -tolerance or max(around) <= tolerance:
            return None, ['Channel phase has no actual raw-ratio closing turn']
    return drive_metrics(raw, pivots, geometry['channelWidthLog'])


def order(row):
    m = row['metrics']
    return (not m.get('driveCleanPass',True), not m['driveZeroBacktrack'], m['driveWorstBacktrackPct'],
            m['driveBacktrackPct'], m['driveWorstGivebackPct'],
            -m['driveCompletedLegs'], -m['formationBars'], row['pair'])


def search(owner):
    if owner.frame != 'daily':
        raise ValueError('Clean drive ranges uses completed daily context only')
    base = channel_search(owner); base_counts = copy.deepcopy(owner.counts)
    owner.clean_drive_evidence = []
    rejections = Counter(); out = []; passing_windows = checked_windows = 0
    for row in base:
        a, b = row['long'], row['short']; full = owner.series(a, b); matches = []
        for n in row['metrics']['passingWindows']:
            raw = full[-n-1:-1]; geometry, reasons = channel_fit(raw)
            if reasons:
                raise ValueError('Existing channel reproduction mismatch')
            checked_windows += 1; metrics, reasons = quality(raw, geometry)
            owner.clean_drive_evidence.append(dict(pair=row['pair'], long=a, short=b, formationBars=n, metrics=metrics, reasons=reasons))
            if metrics is None:
                rejections.update(reasons); continue
            metrics['driveCleanPass'] = not reasons
            metrics['driveCleanlinessFailures'] = reasons
            if reasons: rejections.update(reasons)
            else: passing_windows += 1
            candidate = copy.deepcopy(row); prior = row['metrics']; m = dict(geometry)
            # Preserve held-out close/mark location for this exact chosen window.
            fit_start = owner.by[a]['bars'][-n-1][6]
            floor = m['channelStartTrendLog']+m['channelResidualLowLog']
            last = float(full[-1]); position = (last-floor-m['channelSlopeLogPerDay']*n)/m['channelWidthLog']
            ctx = owner.context(a, b); mark = ctx['currentRatio']; location = None
            if mark:
                now = (owner.meta['serverTime']-fit_start)/86400000
                location = 100*(math.log(mark)-floor-m['channelSlopeLogPerDay']*now)/m['channelWidthLog']
            m.update(metrics, channelFitStartCloseTime=fit_start, channelStepMs=86400000,
                     channelCompletedPositionPct=100*position, channelMarkPositionPct=location,
                     channelLatestOutside=not 0 <= position <= 1,
                     channelMarkOutside=None if location is None else not 0 <= location <= 100,
                     channelDirectionConflict=prior['channelDirectionConflict'],
                     channelWindowDirections=prior['channelWindowDirections'],
                     driveGeometryPassingWindows=prior['passingWindows'])
            candidate['metrics'] = m; candidate['score'] = 100*m['driveEfficiency']
            candidate['stage'] = ('Clean completed daily drives' if m['driveCleanPass'] else 'Near match: fails cleanliness limits')+' · historical shape only, no entry signal'
            matches.append(candidate)
        if matches:
            best = min(matches, key=order)
            best['metrics']['passingWindows'] = sorted(r['metrics']['formationBars'] for r in matches if r['metrics']['driveCleanPass'])
            best['metrics']['driveReviewWindows'] = sorted(r['metrics']['formationBars'] for r in matches)
            out.append(best)
    owner.counts = {**base_counts, 'drivePipeline': dict(
        channelPairs=len(base), channelPassingWindowsChecked=checked_windows,
        cleanDrivePassingWindows=passing_windows, uniqueCleanPairsBeforeHeldExclusion=sum(r['metrics']['driveCleanPass'] for r in out),
        reviewPairsBeforeHeldExclusion=len(out), nearMatchPairsBeforeHeldExclusion=sum(not r['metrics']['driveCleanPass'] for r in out)),
        'driveRejections': dict(rejections)}
    owner.warnings += [
        'Clean-drive overlay: raw DAILY ratio closes between completed confirmed troughs and peaks; no smoothing or detrending of the measured drive path. Includes horizontal, rising and falling ranges with actual swings in both directions.',
        'At least six completed drives, three each way. Aggregate backward distance at most12.5%of forward net advance, worst leg25%, largest continuous giveback20%. Initial unanchored and final unfinished phases excluded; no intraday-path claim.',
        'Strict clean matches are listed first. Closest repeated ranges failing the cleanliness limits are retained and explicitly labelled Near match; they are not clean-drive qualifications.',
        'Zero backward daily steps in every measured drive ranks first, then worst/aggregate backtracking, worst giveback, more drives and longer history. Rounding tolerance only. A historically clean drive can retrace in future.',
        'This is chart-shape ordering only, not best expected profit, a current reversal confirmation or trade direction. Current mark position and outside-channel cautions are shown; no current edge or liquidity/funding eligibility gate.']
    return sorted(out, key=order)
