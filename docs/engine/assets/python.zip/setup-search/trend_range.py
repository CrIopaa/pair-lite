"""Daily uptrend followed by consolidation. Descriptive, template-guided v1.

The prior trend and recent range are separate, consecutive samples. No fills,
returns, account sizing, or synthetic ratio wicks are inferred from this screen.
"""
import math
import numpy as np

WINDOWS = (90, 180, 270)
DAY = 86400000


def prior_metrics(values, days):
    x = np.asarray(values, float)
    if len(x) < days + 362 or not np.isfinite(x[-days-362:]).all():
        return None, ['Missing consecutive daily context']
    # Range is x[-days-1:-1]; trend ends at the immediately preceding close.
    p = x[-days-362:-days-1]
    t = np.arange(len(p), dtype=float); t -= t.mean()
    y = p-p.mean(); ss = float(y@y); cov = float(t@y)
    r2 = cov*cov/float((t@t)*ss) if ss > 0 else 0.
    gain = 100*math.expm1(float(p[-1]-p[0]))
    thirds = np.array([np.quantile(v, [.2, .8]) for v in np.array_split(p, 3)])
    higher = bool(np.all(np.diff(thirds, axis=0) > 0))
    rolling = float(np.mean(p[60:] > p[:-60]))
    delta = np.diff(p); up = float(np.maximum(delta, 0).sum())
    burst = float(max(delta)/up) if up > 0 else 1.
    uplift = 100*math.expm1(float(np.median(x[-days-1:-1])-np.median(p[:60])))
    dd = 100*(-math.expm1(-float(np.max(np.maximum.accumulate(p)-p))))
    tests = [(cov > 0 and r2 >= .45, 'Weak prior daily trend'),
             (gain >= 25, 'Prior rise below25%'),
             (higher, 'Prior distribution not rising'),
             (rolling >= .55, 'Too few rising60-day windows'),
             (burst <= .20, 'One positive day dominates'),
             (uplift >= 20, 'Range not sufficiently above early base')]
    return {'priorTrendDays': 360, 'priorTrendGainPct': gain,
            'priorTrendR2': r2, 'priorTrendDrawdownPct': dd,
            'priorRolling60PositivePct': 100*rolling,
            'priorHigherThirds': higher, 'priorLargestPositiveDaySharePct': 100*burst,
            'rangeUpliftPct': uplift}, [reason for hit, reason in tests if not hit]


def rank_score(geometry, trend_r2, location):
    return .45*geometry['score'] + 35*min(1., max(0., trend_r2)) + 20*(1-min(1., max(0., location)))


def daily_bars_valid(bars, minimum):
    a = np.asarray(bars, float)
    if a.ndim != 2 or len(a) < minimum or a.shape[1] != 7:
        return False
    return bool(np.isfinite(a).all() and np.all(a[:, 1:5] > 0)
                and np.all(a[:, 5] >= 0)
                and np.all(a[:, 2] >= np.max(a[:, [1, 3, 4]], axis=1))
                and np.all(a[:, 3] <= np.min(a[:, [1, 2, 4]], axis=1))
                and np.all(np.diff(a[:, 0]) == DAY)
                and np.all(a[:, 0] % DAY == 0)
                and np.all(a[:, 6]-a[:, 0] == DAY-1))


def leg_tail_metrics(bars):
    a = np.asarray(bars[-30:], float)
    tails = np.maximum(np.log(a[:, 2]/np.maximum(a[:, 1], a[:, 4])),
                       np.log(np.minimum(a[:, 1], a[:, 4])/a[:, 3]))
    return {'p95': 100*math.expm1(float(np.quantile(tails, .95))),
            'max': 100*math.expm1(float(max(tails)))}
