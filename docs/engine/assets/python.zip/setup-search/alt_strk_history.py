"""Optional, retrospective prior-dip evidence on unchanged ALT/STRK candidates.

No historic profit test, future-return estimate, fill model or position writes.
Contract: research/alt_strk_prior_recovery_2026-10-21/contract.json.
"""
import math
from datetime import datetime,timezone
from collections import Counter
from trend_range import daily_bars_valid
from acquire import DAY
VERSION='alt-strk-prior-recovery-v1'

def rsi_series(prices):
    out=[None]*len(prices)
    if len(prices)<15:return out
    changes=[b-a for a,b in zip(prices,prices[1:])]
    gain=sum(max(x,0) for x in changes[:14])/14
    loss=sum(max(-x,0) for x in changes[:14])/14
    for i in range(14,len(prices)):
        if i>14:
            change=changes[i-1];gain=(13*gain+max(change,0))/14;loss=(13*loss+max(-change,0))/14
        if gain+loss>0:out[i]=100*gain/(gain+loss)
    return out

def date(ms):return datetime.fromtimestamp(ms/1000,timezone.utc).strftime('%Y-%m-%d')

def prior_episodes(q,base,current_low):
    """Every event ends strictly before base. First completion deduplicates overlaps."""
    events=[]
    for i in range(max(60,base-365),base-2):
        low=q[i]
        if not current_low/1.25<=low<=current_low*1.25:continue
        if not(low<=min(q[i-2:i]) and low<min(q[i+1:i+3])):continue
        peak_index=max(range(i-60,i),key=lambda j:q[j]);peak=q[peak_index]
        if low>peak*.8:continue
        end=min(i+91,base);target=max(low*1.25,low+.5*(peak-low))
        recovery=next((j for j in range(i+1,end) if q[j]>=target),None)
        if recovery is None:continue
        high_index=max(range(i+1,end),key=lambda j:q[j])
        events.append(dict(peakIndex=peak_index,lowIndex=i,recoveryIndex=recovery,
            highIndex=high_index,peak=peak,low=low,high=q[high_index],
            recovery=q[recovery],threshold=target,declinePct=100*(low/peak-1),
            recoveryPct=100*(q[recovery]/low-1)))
    distinct=[];previous_end=-1
    for event in sorted(events,key=lambda e:(e['recoveryIndex'],e['lowIndex'])):
        if event['peakIndex']<=previous_end:continue
        distinct.append(event);previous_end=event['recoveryIndex']
    return distinct

def analyse(a,b,mark_ratio):
    if not(daily_bars_valid(a,18)and daily_bars_valid(b,18)):
        return None,'Missing or invalid daily history'
    n=min(len(a),len(b));aa=a[-n:];bb=b[-n:]
    if any(x[0]!=y[0] or x[6]!=y[6] for x,y in zip(aa,bb)):
        return None,'Daily histories not synchronized'
    base=n-15;q=[x[4]/y[4]for x,y in zip(aa,bb)]
    low_i=min(range(base+1,n),key=lambda i:q[i]);low=q[low_i]
    ra=rsi_series([x[4]for x in a])[-n:];rb=rsi_series([x[4]for x in b])[-n:]
    long_values=[(i,ra[i])for i in range(base+1,low_i+1)if ra[i]is not None]
    short_values=[(i,rb[i])for i in range(base+1,low_i+1)if rb[i]is not None]
    long_extreme=[(i,v)for i,v in long_values if v<=30]
    short_extreme=[(i,v)for i,v in short_values if v>=70]
    m=dict(priorRecoveryVersion=VERSION,currentDipLow=low,currentDipLowDate=date(aa[low_i][6]),
        currentDipLowTime=aa[low_i][6],currentSetupBaseTime=aa[base][6],
        dipLongMinRSI=min((v for i,v in long_values),default=None),
        dipShortMaxRSI=max((v for i,v in short_values),default=None),
        longOversoldInDip=bool(long_extreme),shortOverboughtInDip=bool(short_extreme),
        stretchSide='Both legs'if long_extreme and short_extreme else'Long oversold'if long_extreme else'Short overbought'if short_extreme else'Neither',
        historicalTroughBarsCovered=len(range(max(60,base-365),base-2)),historyDailyBars=n)
    if not long_extreme and not short_extreme:return m,'No directional leg RSI extreme during current dip'
    if base<63:return m,'Insufficient history for a separate prior dip'
    events=prior_episodes(q,base,low)
    if not events:return m,'No separate similar low with completed prior recovery'
    representative=min(events,key=lambda e:(abs(math.log(e['low']/low)),-e['recoveryIndex']))
    evidence=[dict(peakDate=date(aa[e['peakIndex']][6]),lowDate=date(aa[e['lowIndex']][6]),
        recoveryDate=date(aa[e['recoveryIndex']][6]),highDate=date(aa[e['highIndex']][6]),
        peakTime=aa[e['peakIndex']][6],lowTime=aa[e['lowIndex']][6],recoveryTime=aa[e['recoveryIndex']][6],
        highTime=aa[e['highIndex']][6],peak=e['peak'],low=e['low'],recovery=e['recovery'],high=e['high'],
        declinePct=e['declinePct'],recoveryPct=e['recoveryPct'])for e in events]
    e=representative
    m.update(priorDipRecovery=True,priorRecoveryCount=len(events),priorDipLow=e['low'],
        priorDipLowDate=date(aa[e['lowIndex']][6]),priorRecoveryDate=date(aa[e['recoveryIndex']][6]),
        priorRecoveredHigh=e['high'],priorRecoveredHighDate=date(aa[e['highIndex']][6]),
        priorLowDifferencePct=100*(e['low']/low-1),priorRecoveryPct=e['recoveryPct'],
        priorDeclinePct=e['declinePct'],priorDipLowTime=aa[e['lowIndex']][6],
        priorRecoveryTime=aa[e['recoveryIndex']][6],priorRecoveredHighTime=aa[e['highIndex']][6],
        historicalHighVsMarkPct=100*(e['high']/mark_ratio-1)if mark_ratio and math.isfinite(mark_ratio)and mark_ratio>0 else None,
        priorEpisodes=evidence,
        priorRangeMeaning='Prior closing low and subsequent observed high; not an intact fitted range, future target or fixed-quantity PNL.')
    return m,None

def filter_rows(owner,rows):
    out=[];reject=Counter();evidence=[]
    for row in rows:
        a=owner.by.get(row['long'],{}).get('bars',[]);b=owner.by.get(row['short'],{}).get('bars',[])
        q=owner.context(row['long'],row['short']).get('currentRatio')
        m,reason=analyse(a,b,q)
        evidence.append(dict(long=row['long'],short=row['short'],passed=reason is None,reason=reason,metrics=m))
        if reason:reject[reason]+=1;continue
        out.append({**row,'metrics':{**row['metrics'],**m},'stage':'ALT/STRK turn + prior dip/recovery + directional leg extreme'})
    owner.counts['priorRecovery']={'baseMatches':len(rows),'passed':len(out),'rejected':len(rows)-len(out),**dict(reject)}
    owner.prior_recovery_evidence=evidence
    owner.warnings.append('Optional prior-recovery filter: one or more earlier similar closing lows recovered before the current setup. This is selected historical resemblance, not proof of an intact range or another profitable reversal. RSI stretch is observed during the dip, not required to remain extreme after the bounce.')
    return out
