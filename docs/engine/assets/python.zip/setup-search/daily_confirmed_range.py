"""Daily colour confirmation near unchanged clean-base range edges. Offline only."""
import math
from collections import Counter
from pathlib import Path
import json
from clean_bases import clarity, WINDOWS
from trend_range import daily_bars_valid

DAY=86400000

def candle_direction(a,b):
    """Synchronous ratio candle body; deliberately never divide wick extrema."""
    o=a[1]/b[1]; c=a[4]/b[4]
    return 1 if c>o else -1 if c<o else 0

def qualify(g, closed, current, direction):
    p=(math.log(closed)-g['loLog'])/g['widthLog']
    q=(math.log(current)-g['loLog'])/g['widthLog']
    if direction<0:p,q=1-p,1-q
    return (p,q) if 0<=p<=.30 and 0<=q<=.30 else None

def trade_ratio(quotes,a,b,now,day):
    try:
        A,B=quotes[a],quotes[b];pa,pb=float(A['price']),float(B['price']);ta,tb=int(A['time']),int(B['time'])
        if not all(math.isfinite(v) and v>0 for v in [pa,pb]):return None
        if any(not day<=t<day+DAY or abs(t-now)>120000 for t in [ta,tb]) or abs(ta-tb)>15000:return None
        return pa/pb
    except (KeyError,ValueError,TypeError,OverflowError):return None

def search(owner):
    if owner.frame!='daily':raise ValueError('Daily confirmed ranges requires daily candles')
    path=owner.path/'current_day_opens.json'
    if not path.exists():raise ValueError('Refresh data first: this older snapshot has no verified current UTC daily opens.')
    source=json.loads(path.read_text());day=owner.cut;now=owner.meta['serverTime']
    if source.get('dayStart')!=day or not day<=now<day+DAY:
        raise ValueError('Current daily opens and quote snapshot must belong to the same UTC day. Refresh data.')
    opens=source['opens'];quotes={v['symbol']:v for v in owner.public['data'].get('trades',[])}
    if not quotes:raise ValueError('Refresh data first: synchronized current last-trade quotes are unavailable in this older snapshot.')
    base=owner.ranges(False,WINDOWS);groups={};reject=Counter();passed=0
    for g in base['rows']:
        a,b,n=g['a'],g['b'],g['bars'];A=owner.by[a]['bars'];B=owner.by[b]['bars']
        if not all(daily_bars_valid(v,n+1) for v in [A,B]):reject['Incomplete daily OHLCV']+=1;continue
        quality,reasons=clarity(owner.series(a,b)[-n-1:],g)
        if reasons:reject['Range clarity failed']+=1;continue
        passed+=1
        oa,ob=opens.get(a,{}),opens.get(b,{})
        if not all(v.get('openTime')==day and v.get('closeTime')==day+DAY-1 and isinstance(v.get('open'),(int,float)) and math.isfinite(v['open']) and v['open']>0 for v in [oa,ob]):
            reject['Missing verified current daily open']+=1;continue
        mark=trade_ratio(quotes,a,b,now,day)
        if not mark:reject['Unavailable synchronized current trade quotes']+=1;continue
        direction=candle_direction(A[-1],B[-1]);opened=oa['open']/ob['open']
        if not direction or direction*(mark-opened)<=0:reject['Daily candle colors do not both point inward']+=1;continue
        closed=A[-1][4]/B[-1][4];pos=qualify(g,closed,mark,direction)
        if pos is None:reject['Not inside outer 30% on both clocks']+=1;continue
        L,S=(a,b) if direction>0 else (b,a);p,q=pos
        streak=0
        for aa,bb in zip(reversed(A),reversed(B)):
            if aa[0]!=bb[0] or candle_direction(aa,bb)!=direction:break
            streak+=1
        m=dict(dailyColorConfirmed=True,structureConfirmed=True,sourcePair=a[:-4]+'/'+b[:-4],sourceEdge='bottom' if direction>0 else 'top',
          formationBars=n,daysCovered=n,locationPct=100*q,completedCloseLocationPct=100*p,
          bandLow=g['low'] if direction>0 else 1/g['high'],bandHigh=g['high'] if direction>0 else 1/g['low'],
          bandWidthPct=100*math.expm1(g['widthLog']),boundaryIrregularity=g['shift']+g['mad'],
          boundaryShiftWidths=g['shift'],extremaMADWidths=g['mad'],transitions=g['transitions'],confirmedLows=g['lows'],confirmedHighs=g['highs'],
          completedDailyBodyPct=100*((closed/(A[-1][1]/B[-1][1]))**direction-1),currentDailyBodyPct=100*((mark/opened)**direction-1),
          completedColorStreak=streak,currentDayStart=day,completedDayClose=day-1,currentDayProvisional=True,currentTradeRatio=mark if direction>0 else 1/mark,sourceCurrentTradeRatio=mark,currentDayQuoteBasis='Synchronized last trades; marks are separate context',currentDayQuoteTimeA=quotes[a]['time'],currentDayQuoteTimeB=quotes[b]['time'],**quality)
        row=owner.row(L,S,m,100*(1-q),geometry=g,stage=('Bottom: green closed day + green current day' if direction>0 else 'Top: red closed day + red current day')+' · today provisional')
        key=(a,b)
        if key not in groups or order(row)<order(groups[key]):groups[key]=row
    rows=sorted(groups.values(),key=order)
    owner.counts={**base['counts'],'pipeline':{'broadRangeWindows':len(base['rows']),'clarityPassingWindows':passed,'qualifyingPairsBeforeHeldExclusion':len(rows),'verifiedCurrentDailyOpens':len(opens),'coveredContracts':len(owner.rows)},'rejections':dict(reject)}
    owner.warnings+=['UTC daily ratio candle bodies, not individual coin colors. At least the latest completed day and current provisional day must point inward. Today can change color before closing.',
      'Both latest completed close and synchronized current trade ratio must remain inside the outer 30% of the fitted log range. Current candle color uses last trades, like the chart; mark-price context is separate. Closest oriented edge ranks first. Top matches invert the displayed long/short pair.',
      'Unchanged clean-bases numerical geometry over 90/180/360 days; every window tested. This is color confirmation, not proof the bottom/top will hold. No funding, cost or future-profit qualification.']
    return rows

def order(row):
    m=row['metrics'];return (m['locationPct'],-m['swingEfficiencyMedian'],m['boundaryIrregularity'],-m['formationBars'],row['pair'])
