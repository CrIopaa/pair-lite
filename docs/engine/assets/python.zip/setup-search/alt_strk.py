"""Selected ALT/STRK-template reversal screen; no trading or performance model.

Fixed daily setup and completed hourly confirmation. Older pump engines stay
unchanged. Contract: research/alt_strk_button_2026-10-21/contract.json.
"""
import math
from collections import Counter
import numpy as np
from acquire import read, DAY, HOUR
from trend_range import daily_bars_valid

# Original pre-entry template, frozen in the 18 October descriptive study.
REFERENCE = (0.07805609915198941, 0.8910701460378263,
             -0.3583786857282105, 0.5769291526781895)
SCALES = (.2, 1., .4, .6)


def distance(long_gain, short_gain, fade, rebound):
    return sum(abs((x-y)/s) for x, y, s in
               zip((long_gain, short_gain, -fade, rebound), REFERENCE, SCALES))/4


def hourly_closes(row, cutoff):
    if not row or not row.get('complete'):
        return None
    bs = row.get('bars', [])[-5:]
    if len(bs) != 5:
        return None
    for i, b in enumerate(bs):
        if len(b) != 7 or not all(isinstance(x, (int, float)) and math.isfinite(x) for x in b):
            return None
        if not (b[0] == cutoff-(5-i)*HOUR and b[6] == b[0]+HOUR-1
                and min(b[1:5]) > 0 and b[5] >= 0
                and b[2] >= max(b[1:5]) and b[3] <= min(b[1:5])):
            return None
    return [b[4] for b in bs]


def order(row):
    return (row['metrics']['referenceDistance'], row['pair'])


def search(owner):
    if owner.frame != 'daily':
        raise ValueError('ALT/STRK reversal uses fixed daily setup and hourly timing')
    now = owner.meta['serverTime']; rejected = Counter(); out = []
    counts = dict(inputContracts=len(owner.rows), validDailyQuotes=0,
                  possibleOrientedPairs=0, pumpShortCoins=0,
                  orientedPairsWithPumpShort=0, divergencePairs=0,
                  recoveredPairs=0, timingConfirmedPairs=0, retainedAtMarkPairs=0)
    owner.counts = {'pipeline':counts, 'rejections':rejected}
    if owner.cut != now//DAY*DAY:
        owner.warnings.append('Daily candles do not end at this snapshot’s latest completed daily close. Refresh daily + 1h data.')
        return []
    try:
        h = read(owner.path/'hourly.json')
    except (FileNotFoundError, ValueError):
        owner.warnings.append('Hourly confirmation data unavailable. Refresh daily + 1h data; no turn is inferred.')
        return []
    hcut = h.get('cutoffExclusive')
    if h.get('step') != HOUR or hcut != now//HOUR*HOUR:
        owner.warnings.append('Hourly data are stale or misaligned for this snapshot. Refresh daily + 1h data.')
        return []
    hm = {r['symbol']:r for r in h.get('rows', [])}
    coins = {}
    for r in owner.rows:
        s = r['symbol']; bs = r['bars']
        if not daily_bars_valid(bs, 18):
            rejected['Invalid or insufficient daily OHLCV'] += 1; continue
        ctx = owner.context(s, s); mark = ctx['legs'][0]['mark']
        if not ctx['currentRatio'] or not mark:
            rejected['Missing or stale snapshot mark'] += 1; continue
        close = np.asarray([b[4] for b in bs], float)
        coins[s] = dict(close=close, mark=mark, base=close[-15],
                        gain=mark/close[-15]-1,
                        pump=max(close[k]/close[k-3]-1 for k in range(len(close)-14,len(close))),
                        fade=1-mark/max(mark,max(close[-14:])),
                        hourly=hourly_closes(hm.get(s), hcut))
    counts['validDailyQuotes'] = len(coins)
    counts['possibleOrientedPairs'] = len(coins)*(len(coins)-1)
    shorts = {s:c for s,c in coins.items() if c['pump'] >= .30 and c['gain'] >= .15 and .05 <= c['fade'] <= .45}
    counts['pumpShortCoins'] = len(shorts)
    for S, s in shorts.items():
        for L, l in coins.items():
            if L == S: continue
            counts['orientedPairsWithPumpShort'] += 1
            if l['gain'] > .20 or s['gain']-l['gain'] < .20:
                rejected['Insufficient relative divergence'] += 1; continue
            ctx = owner.context(L,S); q = ctx['currentRatio']
            if not q:
                rejected['Pair marks not synchronized'] += 1; continue
            fall = q/(l['base']/s['base'])-1
            if fall > -.20:
                rejected['Ratio fall below20%'] += 1; continue
            counts['divergencePairs'] += 1
            rebound = q/min(l['close'][-14:]/s['close'][-14:])-1
            if rebound < .05:
                rejected['Ratio recovery below5%'] += 1; continue
            counts['recoveredPairs'] += 1
            lh, sh = l['hourly'], s['hourly']
            if lh is None or sh is None:
                rejected['Missing valid completed hourly timing'] += 1; continue
            lr = lh[-1]/lh[0]-1; sr = sh[-1]/sh[0]-1
            if not (lr > 0 and sr < 0):
                rejected['Long-up / short-down4h turn absent'] += 1; continue
            counts['timingConfirmedPairs'] += 1
            completed_ratio = lh[-1]/sh[-1]; turn_start_ratio = lh[0]/sh[0]
            if q <= turn_start_ratio:
                rejected['Snapshot ratio erased observed4h recovery'] += 1; continue
            counts['retainedAtMarkPairs'] += 1
            dist = distance(l['gain'],s['gain'],s['fade'],rebound)
            metrics = dict(altStrkStyle=True, referenceDistance=dist,
                dailyContextLastClose=owner.cut-1, hourlyCutoff=hcut,
                completedTimingLastClose=hcut-1, lookbackBars=14,
                long14BarPct=100*l['gain'], short14BarPct=100*s['gain'],
                shortMax3BarPumpPct=100*s['pump'], shortFadePct=100*s['fade'],
                outperformancePP=100*(s['gain']-l['gain']), ratioFallPct=100*fall,
                ratioReboundPct=100*rebound, long4hPct=100*lr,
                short4hPricePct=100*sr, ratio4hPct=100*((1+lr)/(1+sr)-1),
                bothGreen4h=True, snapshotVsTimingRatioPct=100*(q/completed_ratio-1),
                snapshotVsTurnStartPct=100*(q/turn_start_ratio-1),
                timingMeaning='Last five completed hourly closes span4hours; not aligned4h trade candles.',
                referenceMeaning='Lower distance means closer to original pre-entry template; not expected profit.',
                fundingEligibility='Unverified; price similarity only')
            out.append(owner.row(L,S,metrics,-dist,
                stage='ALT/STRK-style divergence + observed4h turn · review candidate'))
    counts['matchingLongCoins'] = len({r['long'] for r in out})
    counts['matchingShortCoins'] = len({r['short'] for r in out})
    owner.warnings += [
        'Selected-winner similarity, not a validated trading rule. No intact horizontal range is required.',
        'Four-hour confirmation uses completed hourly closes: long up, short down. Snapshot ratio must remain above the beginning of that recovery; small pullbacks from the final hourly close are allowed. This does not guarantee future profits on either leg.',
        'Daily-base returns compare snapshot marks with the15thlatestcompleted daily close. Pump and recent peaks/lows use completed daily candles. No unfinished candle is treated as closed.',
        'Rank is closeness to original ALT/STRK pre-entry values, not strongest expected return. Shared short/long coins create dependent candidates.',
        'Funding, execution costs, liquidity and account risk are context only, not cleared entry eligibility.']
    return sorted(out,key=order)
